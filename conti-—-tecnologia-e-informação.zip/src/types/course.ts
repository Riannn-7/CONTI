export interface ContentTable {
  title?: string;
  headers: string[];
  rows: string[][];
}

export interface InfographicItem {
  id: string;
  src: string;
  title: string;
  caption: string;
  alt: string;
  afterParagraphIndex: number;
}

export interface Subtopic {
  id: string; // e.g. '1.1', '1.2'
  slotKey: string; // e.g. '1_1'
  code: string;
  title: string;
  paragraphs: string[];
  table?: ContentTable;
  tableAfterParagraphIndex?: number;
  infographics?: InfographicItem[];
}

export interface QuizQuestion {
  id: string;
  prompt: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
}

export interface CourseModule {
  id: string; // 'mod-1', 'mod-2', 'mod-3'
  number: number;
  title: string;
  shortTitle: string;
  description: string;
  subtopics: Subtopic[];
  references: string[];
  quiz: QuizQuestion[];
}

export interface PersistedProgress {
  studiedSubtopics: string[];
  quizScores: Record<string, { score: number; total: number }>;
}

export type ActiveRoute =
  | { type: 'home' }
  | { type: 'subtopic'; moduleId: string; subtopicId: string }
  | { type: 'quiz'; moduleId: string };
