import React from 'react';
import { Gamepad2, Layers, Sparkles } from 'lucide-react';

interface GameSlotProps {
  subtopicId: string;
  subtopicTitle: string;
  conceptFocus: string;
}

const GameSlotPlaceholder: React.FC<GameSlotProps> = ({
  subtopicId,
  subtopicTitle,
  conceptFocus,
}) => {
  return (
    <div className="rounded-xl bg-[#030B26]/80 border border-dashed border-[#00B4FF]/40 p-6 sm:p-8 text-center">
      <div className="mx-auto w-14 h-14 rounded-xl conti-gradient flex items-center justify-center text-white shadow-lg shadow-[#00B4FF]/15 mb-5">
        <Gamepad2 className="w-7 h-7" aria-hidden="true" />
      </div>

      <p className="text-xs font-mono uppercase tracking-wider text-[#00B4FF] mb-2">
        Módulo Interativo · Subtópico {subtopicId}
      </p>

      <h3 className="text-lg sm:text-xl font-display font-bold text-white mb-3">
        Espaço Reservado para o Mini-Jogo Interativo — Em desenvolvimento pelo grupo
      </h3>

      <p className="text-sm sm:text-base text-[#CBD5E1] max-w-xl mx-auto leading-relaxed mb-6">
        Este módulo receberá o desafio prático desenvolvido pela equipe de Ciências Contábeis para
        avaliar na prática os conceitos de <strong className="text-white">{subtopicTitle}</strong>:{' '}
        {conceptFocus}
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mx-auto text-left">
        <div className="p-3.5 rounded-lg bg-[#0A163D] border conti-border flex items-start gap-3">
          <Layers className="w-4 h-4 text-[#00B4FF] shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="text-xs font-semibold text-white">Integração Modular</p>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              Slot isolado pronto para acoplar o componente do jogo sem alterar a estrutura da página.
            </p>
          </div>
        </div>
        <div className="p-3.5 rounded-lg bg-[#0A163D] border conti-border flex items-start gap-3">
          <Sparkles className="w-4 h-4 text-[#4F46E5] shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="text-xs font-semibold text-white">Aplicação Contábil</p>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              Dinâmica voltada à fixação ativa dos conceitos teóricos aplicados à rotina contábil.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Renderizador modular dos mini-jogos por subtópico.
 * Para acoplar o jogo definitivo de cada assunto, substitua apenas o retorno do respectivo case.
 */
export function renderSubtopicGame(subtopicId: string, subtopicTitle: string): React.ReactNode {
  switch (subtopicId) {
    // SLOT_JOGO_SUBTOPICO_1_1
    case '1.1':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="ciclo sistêmico (entradas, processamento, saídas e feedback), pirâmide informacional (dado, informação e conhecimento) e vertentes do SIC."
        />
      );

    // SLOT_JOGO_SUBTOPICO_1_2
    case '1.2':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="operacionalidade, integração em base única de dados (globalismo) e relação custo-benefício da informação contábil."
        />
      );

    // SLOT_JOGO_SUBTOPICO_1_3
    case '1.3':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="os nove subsistemas funcionais do SIC e a integração com indicadores físicos de áreas não contábeis."
        />
      );

    // SLOT_JOGO_SUBTOPICO_1_4
    case '1.4':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="relevância, representação fidedigna e características de melhoria do CPC 00 (R2) aplicadas aos relatórios."
        />
      );

    // SLOT_JOGO_SUBTOPICO_2_1
    case '2.1':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="parametrização versus customização, arquitetura de banco único e etapas de implantação (go-live) de um ERP."
        />
      );

    // SLOT_JOGO_SUBTOPICO_2_2
    case '2.2':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="relatórios programados, relatórios de exceção, KPIs e acompanhamento de Orçado vs. Realizado na Controladoria."
        />
      );

    // SLOT_JOGO_SUBTOPICO_2_3
    case '2.3':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="simulações What-If, análise de sensibilidade, planejamento tributário e cruzamento com variáveis externas no nível estratégico."
        />
      );

    // SLOT_JOGO_SUBTOPICO_2_4
    case '2.4':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="os 5 Vs do Big Data, cruzamentos fiscais do SPED e auditoria contínua com técnicas como a Lei de Benford."
        />
      );

    // SLOT_JOGO_SUBTOPICO_3_1
    case '3.1':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="os cinco componentes da metodologia COSO (2013) e controles preventivos, detectivos (logs de auditoria) e corretivos."
        />
      );

    // SLOT_JOGO_SUBTOPICO_3_2
    case '3.2':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="diferenciação entre erro e fraude, Triângulo da Fraude de Cressey e deveres éticos da NBC PG 01."
        />
      );

    // SLOT_JOGO_SUBTOPICO_3_3
    case '3.3':
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="papéis de Controlador e Operador, bases legais de guarda documental contábil e segurança técnica do Art. 46 da LGPD."
        />
      );

    default:
      return (
        <GameSlotPlaceholder
          subtopicId={subtopicId}
          subtopicTitle={subtopicTitle}
          conceptFocus="conceitos fundamentais do subtópico selecionado."
        />
      );
  }
}
