import { useEffect, useMemo, useState } from 'react';
import { Home, Menu, PanelLeftOpen } from 'lucide-react';
import { COURSE_MODULES } from './data/courseContent';
import type { ActiveRoute, PersistedProgress, Subtopic } from './types/course';
import {
  clearProgressFromStorage,
  EMPTY_PROGRESS,
  getOverallProgress,
  isSubtopicStudied,
  loadProgressFromStorage,
  saveProgressToStorage,
  toggleSubtopicStudied,
} from './utils/progress';
import { HomeHub } from './components/HomeHub';
import { StudySidebar } from './components/StudySidebar';
import { SubtopicView } from './components/SubtopicView';
import { ModuleQuizView } from './components/ModuleQuizView';
import { SubtopicGameModal } from './components/SubtopicGameModal';
import { ContiLogo } from './components/ContiLogo';

function getRouteFromLocation(): ActiveRoute {
  if (typeof window !== 'undefined') {
    const hash = window.location.hash.replace(/^#\/?/, '');
    if (hash) {
      const [moduleId, target] = hash.split('/');
      const mod = COURSE_MODULES.find((m) => m.id === moduleId);
      if (mod) {
        if (target === 'avaliacao') {
          return { type: 'quiz', moduleId: mod.id };
        }
        const sub = mod.subtopics.find((s) => s.id === target);
        if (sub) {
          return { type: 'subtopic', moduleId: mod.id, subtopicId: sub.id };
        }
      }
    }

    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      const firstMod = COURSE_MODULES[0];
      const firstSub = firstMod?.subtopics[0];
      if (firstMod && firstSub) {
        return { type: 'subtopic', moduleId: firstMod.id, subtopicId: firstSub.id };
      }
    }
  }
  return { type: 'home' };
}

export default function App() {
  const [progress, setProgress] = useState<PersistedProgress>(() => loadProgressFromStorage());
  const [route, setRoute] = useState<ActiveRoute>(() => getRouteFromLocation());
  const [isDesktopSidebarOpen, setIsDesktopSidebarOpen] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [expandedModuleIds, setExpandedModuleIds] = useState<string[]>(['mod-1']);
  const [activeGameSubtopic, setActiveGameSubtopic] = useState<Subtopic | null>(null);

  useEffect(() => {
    saveProgressToStorage(progress);
  }, [progress]);

  // Sincroniza a rota atual no hash da URL e responde a navegação por histórico/hash
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onHashChange = () => {
      setRoute(getRouteFromLocation());
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (route.type === 'home') {
      if (window.location.hash) {
        window.history.replaceState(null, '', window.location.pathname + window.location.search);
      }
    } else if (route.type === 'subtopic') {
      const targetHash = `#/${route.moduleId}/${route.subtopicId}`;
      if (window.location.hash !== targetHash) {
        window.history.replaceState(null, '', targetHash);
      }
    } else if (route.type === 'quiz') {
      const targetHash = `#/${route.moduleId}/avaliacao`;
      if (window.location.hash !== targetHash) {
        window.history.replaceState(null, '', targetHash);
      }
    }
  }, [route]);

  // Garante que o módulo ativo esteja expandido na barra lateral
  useEffect(() => {
    if (route.type === 'subtopic' || route.type === 'quiz') {
      setExpandedModuleIds((prev) =>
        prev.includes(route.moduleId) ? prev : [...prev, route.moduleId]
      );
    }
  }, [route]);

  // Fecha a gaveta mobile com Escape
  useEffect(() => {
    if (!isMobileSidebarOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsMobileSidebarOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isMobileSidebarOpen]);

  const flatSubtopics = useMemo(
    () =>
      COURSE_MODULES.flatMap((mod) =>
        mod.subtopics.map((sub) => ({ moduleId: mod.id, subtopic: sub }))
      ),
    []
  );

  const overall = useMemo(
    () => getOverallProgress(progress, COURSE_MODULES),
    [progress]
  );

  const handleOpenModule = (moduleId: string, subtopicId?: string) => {
    const mod = COURSE_MODULES.find((m) => m.id === moduleId) ?? COURSE_MODULES[0];
    const targetSubId = subtopicId ?? mod.subtopics[0]?.id;
    if (!targetSubId) return;
    setRoute({ type: 'subtopic', moduleId: mod.id, subtopicId: targetSubId });
    setExpandedModuleIds((prev) =>
      prev.includes(mod.id) ? prev : [...prev, mod.id]
    );
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenQuiz = (moduleId: string) => {
    setRoute({ type: 'quiz', moduleId });
    setExpandedModuleIds((prev) =>
      prev.includes(moduleId) ? prev : [...prev, moduleId]
    );
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateHome = () => {
    setRoute({ type: 'home' });
    setIsMobileSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleAccordion = (moduleId: string) => {
    setExpandedModuleIds((prev) =>
      prev.includes(moduleId)
        ? prev.filter((id) => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  const handleToggleStudied = (subtopicId: string) => {
    setProgress((prev) => toggleSubtopicStudied(prev, subtopicId));
  };

  const handleSaveQuizScore = (moduleId: string, score: number, total: number) => {
    setProgress((prev) => ({
      ...prev,
      quizScores: {
        ...prev.quizScores,
        [moduleId]: { score, total },
      },
    }));
  };

  const handleClearProgress = () => {
    clearProgressFromStorage();
    setProgress(EMPTY_PROGRESS);
  };

  if (route.type === 'home') {
    return (
      <HomeHub
        modules={COURSE_MODULES}
        progress={progress}
        onOpenModule={handleOpenModule}
        onOpenQuiz={handleOpenQuiz}
      />
    );
  }

  const activeModule =
    COURSE_MODULES.find((m) => m.id === route.moduleId) ?? COURSE_MODULES[0];

  const activeSubtopic =
    route.type === 'subtopic'
      ? activeModule.subtopics.find((s) => s.id === route.subtopicId) ??
        activeModule.subtopics[0]
      : null;

  const flatIndex = activeSubtopic
    ? flatSubtopics.findIndex((item) => item.subtopic.id === activeSubtopic.id)
    : -1;

  const prevSubtopic = flatIndex > 0 ? flatSubtopics[flatIndex - 1] : null;
  const nextSubtopic =
    flatIndex >= 0 && flatIndex < flatSubtopics.length - 1
      ? flatSubtopics[flatIndex + 1]
      : null;

  const isLastInModule = Boolean(
    activeSubtopic &&
      activeModule.subtopics[activeModule.subtopics.length - 1]?.id ===
        activeSubtopic.id
  );

  return (
    <div className="min-h-screen bg-[#030B26] text-[#E2E8F0] flex">
      <StudySidebar
        modules={COURSE_MODULES}
        progress={progress}
        activeRoute={route}
        isDesktopOpen={isDesktopSidebarOpen}
        isMobileOpen={isMobileSidebarOpen}
        expandedModuleIds={expandedModuleIds}
        onToggleDesktop={() => setIsDesktopSidebarOpen((prev) => !prev)}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        onToggleAccordion={handleToggleAccordion}
        onNavigateHome={handleNavigateHome}
        onSelectSubtopic={handleOpenModule}
        onSelectQuiz={handleOpenQuiz}
        onToggleStudied={handleToggleStudied}
        onClearProgress={handleClearProgress}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        {/* Barra Superior do Ambiente de Estudo */}
        <header className="sticky top-0 z-30 h-14 px-4 sm:px-6 bg-[#030B26]/90 backdrop-blur-md border-b conti-border flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            {/* Abrir drawer mobile */}
            <button
              type="button"
              onClick={() => setIsMobileSidebarOpen(true)}
              aria-label="Abrir menu de módulos"
              className="lg:hidden w-10 h-10 rounded-lg bg-[#0A163D] border conti-border text-[#E2E8F0] hover:text-white hover:border-[#00B4FF] flex items-center justify-center transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <Menu className="w-5 h-5" aria-hidden="true" />
            </button>

            {/* Expandir sidebar no desktop quando recolhida */}
            {!isDesktopSidebarOpen && (
              <button
                type="button"
                onClick={() => setIsDesktopSidebarOpen(true)}
                aria-label="Expandir barra lateral"
                title="Expandir barra lateral"
                className="hidden lg:inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0A163D] border conti-border text-xs font-semibold text-[#E2E8F0] hover:text-white hover:border-[#00B4FF] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
              >
                <PanelLeftOpen className="w-4 h-4 text-[#00B4FF]" aria-hidden="true" />
                <span>Módulos</span>
              </button>
            )}

            {(!isDesktopSidebarOpen || true) && (
              <div className="lg:hidden">
                <ContiLogo size="sm" />
              </div>
            )}

            <span className="hidden sm:inline-block text-xs font-medium text-[#94A3B8] truncate">
              {route.type === 'subtopic' && activeSubtopic
                ? `Módulo ${activeModule.number} · Subtópico ${activeSubtopic.code}`
                : `Módulo ${activeModule.number} · Atividade Avaliativa`}
            </span>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <span className="hidden sm:inline text-xs text-[#CBD5E1] tabular-nums whitespace-nowrap">
              Progresso:{' '}
              <strong
                className={
                  overall.percent === 100 ? 'text-[#10B981]' : 'text-[#00B4FF]'
                }
              >
                {overall.percent}%
              </strong>{' '}
              ({overall.completed}/{overall.total})
            </span>

            <button
              type="button"
              onClick={handleNavigateHome}
              className="py-1.5 px-3 rounded-lg bg-[#0A163D] border conti-border text-xs font-semibold text-[#E2E8F0] hover:text-white hover:border-[#00B4FF] inline-flex items-center gap-1.5 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <Home className="w-3.5 h-3.5 text-[#00B4FF]" aria-hidden="true" />
              <span>Menu Inicial</span>
            </button>
          </div>
        </header>

        <main className="flex-1">
          {route.type === 'subtopic' && activeSubtopic ? (
            <SubtopicView
              module={activeModule}
              subtopic={activeSubtopic}
              isStudied={isSubtopicStudied(progress, activeSubtopic.id)}
              prevSubtopic={prevSubtopic}
              nextSubtopic={nextSubtopic}
              isLastInModule={isLastInModule}
              onToggleStudied={handleToggleStudied}
              onOpenGame={(sub) => setActiveGameSubtopic(sub)}
              onNavigateSubtopic={handleOpenModule}
              onNavigateQuiz={handleOpenQuiz}
            />
          ) : (
            <ModuleQuizView
              module={activeModule}
              previousScore={progress.quizScores[activeModule.id]}
              onSaveQuizScore={handleSaveQuizScore}
              onBackToModule={handleOpenModule}
            />
          )}
        </main>
      </div>

      <SubtopicGameModal
        subtopic={activeGameSubtopic}
        onClose={() => setActiveGameSubtopic(null)}
      />
    </div>
  );
}
