import type { CourseModule } from '../types/course';

export const COURSE_MODULES: CourseModule[] = [
  {
    id: 'mod-1',
    number: 1,
    title: 'Fundamentos dos Sistemas de Informação Contábil (SIC)',
    shortTitle: 'Fundamentos do SIC',
    description:
      'Bases epistemológicas da Teoria Geral dos Sistemas, pirâmide informacional, pilares de validade perene, subsistemas funcionais e características qualitativas do CPC 00 (R2).',
    subtopics: [
      {
        id: '1.1',
        slotKey: '1_1',
        code: '1.1',
        title: 'Teoria Geral dos Sistemas, Pirâmide Informacional e Conceito de SIC',
        paragraphs: [
          'A compreensão dos Sistemas de Informação Contábil inicia-se na própria noção epistemológica de sistema, termo derivado do grego *sietemiun*, que remete à ideia de combinar, ajustar e formar um conjunto coordenado. Sob a ótica da abordagem sistêmica, um sistema consiste em um conjunto de elementos interdependentes que interagem entre si em busca de objetivos comuns, constituindo um todo organizado. Como destaca Alvarez (1990), o princípio fundamental dessa lógica reside na sinergia: o todo é sempre maior que a soma de suas partes, pois o comportamento conjunto das unidades produz resultados superiores àqueles que seriam obtidos caso operassem de forma isolada. Essa lógica sustenta a Teoria Geral dos Sistemas (TGS), formulada originalmente por Ludwig von Bertalanffy e difundida na gestão organizacional, segundo a qual fenômenos complexos — sejam biológicos, econômicos ou empresariais — compartilham leis estruturais comuns e só podem ser compreendidos globalmente por meio das interdependências entre seus componentes (Souza, 2015).',
          'Todo sistema é delimitado por sua função, que supre as demandas do meio externo, e por sua estrutura, que concretiza essa função mediante parâmetros operacionais bem definidos. O ciclo sistêmico opera a partir de **entradas** (*inputs*), que fornecem os insumos, dados ou energia necessários para iniciar o processo; passa pelo **processamento** (*throughput*), mecanismo interno de conversão e transformação; e culmina nas **saídas** (*outputs*), que materializam a finalidade para a qual o sistema foi concebido. Para evitar desvios operacionais, o sistema depende da **retroação** (*feedback*), mecanismo de controle que compara as saídas obtidas com padrões previamente estabelecidos, tudo isso imerso em um **ambiente** externo com o qual mantém troca constante. Quanto à sua constituição, os sistemas dividem-se em físicos ou concretos (como o *hardware*, equipamentos e máquinas) e abstratos (como o *software*, planos, conceitos e regras contábeis). Quanto à sua natureza, diferenciam-se entre sistemas fechados, que são herméticos ao meio externo (como um relógio ou termostato), e sistemas abertos, que realizam intercâmbio contínuo com o ambiente (Souza, 2015).',
          'As organizações contemporâneas configuram-se tipicamente como sistemas abertos e organizados. Diferentemente dos sistemas vivos — que possuem estrutura física concreta e ciclo de vida biológico pré-determinado —, as empresas são sistemas abstratos de natureza psicossocial que adquirem estrutura em estágios, dependem de cooperação externa e podem se reorganizar continuamente sem prazo de validade definido. No ambiente corporativo, o funcionamento desse sistema aberto articula seis funções vitais: a **ingestão** de recursos financeiros, materiais e humanos; o **processamento** produtivo que culmina na venda; a **reação ao ambiente** diante de mudanças legais, econômicas ou tecnológicas; o **suprimento das partes** por meio de remuneração e sentido funcional; a **regeneração das partes**, garantindo manutenção de máquinas e reposição de pessoal; e a **organização**, exercida por um sistema de comunicações voltado ao planejamento e controle (Souza, 2015).',
          'É exatamente nessa função de comunicação e controle que se insere a tríade da empresa contemporânea — formada por **pessoas, informações e tecnologias** — e o conceito de Sistema de Informação (SI). Segundo Padoveze (2010), um Sistema de Informação é o conjunto de recursos humanos, materiais, tecnológicos e financeiros agregados segundo uma sequência lógica para processar dados e traduzi-los em informações que permitam à organização cumprir seus objetivos principais. Nesse fluxo, estabelece-se a hierarquia da pirâmide informacional: o **dado** é o registro bruto e isolado (como o valor `R$ 48.500,00` e uma data); a **informação** surge quando esse dado é processado, classificado e contextualizado (identificando que o valor corresponde a uma duplicata a receber de um cliente específico); e o **conhecimento** manifesta-se quando o profissional aplica sua experiência técnica sobre a informação para decidir (por exemplo, avaliando o risco de inadimplência desse cliente para constituir uma perda estimada).',
          'Dentro dessa arquitetura empresarial, a Contabilidade estrutura-se como um subsistema formal de informação e avaliação. Conforme diretriz consolidada pela Comissão de Valores Mobiliários (CVM) e pelo IBRACON, a Contabilidade é objetivamente um sistema de informação e avaliação destinado a prover seus usuários com demonstrações e análises de natureza econômica, financeira, física e de produtividade sobre a entidade contabilizada. O Sistema de Informação Contábil (SIC) organiza-se em três grandes vertentes: a **Contabilidade Financeira** (voltada às exigências societárias, fiscais e usuários externos), a **Contabilidade Gerencial** (focada no controle interno e suporte à administração) e a **Contabilidade Estratégica** (direcionada ao planejamento de longo prazo, gestão de riscos e análise de concorrentes). Seus produtos atendem tanto aos **usuários internos** (sócios, diretores, gerentes e empregados que conduzem a operação) quanto aos **usuários externos**, subdivididos entre aqueles com interesse financeiro direto (investidores e credores) e aqueles com interesse indireto ou regulatório (Fisco, órgãos governamentais, clientes e sociedade).',
        ],
        infographics: [
          {
            id: 'empresa-sistema-aberto',
            src: '/assets/aistudio/empresa-sistema-aberto.png_eb631f17.png',
            title: 'A Empresa como Sistema Aberto',
            caption:
              'As 6 funções vitais da organização, entradas, saídas e ciclo de retroação (Souza, 2015).',
            alt: 'Infográfico A Empresa como Sistema Aberto ilustrando entradas do ambiente externo, processamento nas 6 funções vitais, saídas e ciclo de retroação/feedback.',
            afterParagraphIndex: 2,
          },
          {
            id: 'piramide-informacional-contabilidade',
            src: '/assets/aistudio/piramide-informacional-contabilidade.png_dfaee7ce.png',
            title: 'Pirâmide Informacional da Contabilidade',
            caption:
              'Como o SIC transforma registros brutos (Dados) em Informação e Conhecimento para decisões estratégicas.',
            alt: 'Infográfico Pirâmide Informacional da Contabilidade detalhando a evolução de Dado (registros brutos), Informação (processamento e contexto) até Conhecimento (diagnóstico e decisão contábil).',
            afterParagraphIndex: 3,
          },
        ],
      },
      {
        id: '1.2',
        slotKey: '1_2',
        code: '1.2',
        title: 'Princípios Básicos e Fundamentos de Validade Perene do SIC',
        paragraphs: [
          'Para que um Sistema de Informação Contábil não se torne meramente um repositório burocrático de obrigações fiscais, mas mantenha validade perene e utilidade real dentro da organização, Padoveze (2010) estabelece que sua arquitetura deve repousar sobre três fundamentos estruturais indissociáveis: **operacionalidade**, **integração** e **custo da informação**. Esses pilares dialogam diretamente com os conceitos de **eficiência** (executar processos de forma otimizada e com redução de gastos) e **eficácia** (atingir os objetivos decisórios da organização) proporcionados pela Tecnologia da Informação.',
          'O fundamento da **operacionalidade** exige que os dados sejam coletados, armazenados e processados de modo prático, ágil e orientado à ação gerencial. Um SIC operacional produz relatórios concisos, moldados às necessidades específicas de cada gestor e construídos a partir de dados objetivos que permitam entendimento imediato. Mais do que exibir números, a apresentação visual e a manipulação do relatório devem ser tão claras e completas que não deixem margem para dúvidas nem provoquem questionamentos básicos sobre informações ausentes do objeto analisado (Padoveze, 2010). Essa qualidade operacional sustenta a **tempestividade**, assegurando que a informação chegue ao tomador de decisão no momento exato em que ainda possui capacidade de influenciar o rumo dos negócios.',
          'O segundo fundamento é a **integração**, condição segundo a qual todas as áreas necessárias ao gerenciamento da informação contábil estão abrangidas por um único sistema corporativo. Em um ambiente integrado, todos os departamentos alimentam e consultam uma mesma base de dados (*single source of truth*), eliminando sistemas paralelos isolados e a redigitação manual de documentos (Padoveze, 2010). Essa unicidade reforça diretamente a **confiabilidade** e a característica sistêmica do **globalismo**, segundo a qual um estímulo ou lançamento ocorrido em uma unidade repercute automaticamente em todo o sistema. Na prática contábil, quando o setor de almoxarifado registra a entrada física de mercadorias conferidas por Nota Fiscal Eletrônica, o SIC integrado atualiza simultaneamente o saldo de estoques, gera o passivo no contas a pagar do financeiro, apura os créditos tributários no módulo fiscal e efetua o lançamento contábil correspondente, preservando a trilha de auditoria sem intervenção humana redundante.',
          'Por fim, o princípio do **custo da informação** impõe uma restrição econômica racional ao projeto tecnológico: o SIC deve ser continuamente avaliado sob a relação custo-benefício (Padoveze, 2010). O investimento financeiro e operacional exigido para capturar, armazenar, proteger e processar um dado jamais pode superar o benefício econômico e decisório que a informação resultante proporcionará à entidade. Se o custo para rastrear centavos em itens de material de expediente irrelevantes exige horas de trabalho de analistas e licenças caras de *software*, o sistema perde racionalidade econômica.',
        ],
      },
      {
        id: '1.3',
        slotKey: '1_3',
        code: '1.3',
        title: 'Abrangência Setorial e Subsistemas do SIC',
        paragraphs: [
          'A abrangência do Sistema de Informação Contábil reflete sua capacidade de conectar e traduzir economicamente todas as atividades desempenhadas pela empresa. Conforme a estruturação proposta por Padoveze (2010), o SIC não se limita aos livros Diário e Razão, mas desdobra-se em nove componentes funcionais que interligam os setores administrativos, operacionais e estratégicos da organização.',
          'O núcleo estrutural desse ecossistema é a **Contabilidade Financeira**, que compreende a escrituração tradicional, os aspectos societários e os registros em moeda nacional. Sua importância é vital porque abriga a arquitetura básica do plano de contas e os lançamentos primários que garantem a continuidade e a integridade de todo o restante do sistema. A partir desse núcleo, o SIC expande-se para a **Contabilidade em Outras Moedas**, indispensável em uma economia globalizada para converter demonstrações e controlar variações cambiais em operações de importação, exportação ou consolidação de filiais estrangeiras, e para a **Contabilidade Tributária**, encarregada da apuração, gestão e planejamento de tributos, avaliando antecipadamente o impacto fiscal de cada decisão empresarial (Padoveze, 2010).',
          'No elo com as operações internas, destaca-se a **Contabilidade de Custos**, subsistema imprescindível que conecta a contabilidade à área produtiva, permitindo valorar inventários, ratear custos indiretos, formar preços de venda e atender às exigências fiscais de integração contábil. Paralelamente, o subsistema de **Administração Financeira e Orçamentos** incorpora as técnicas orçamentárias e o controle do fluxo de caixa em todos os níveis de responsabilidade da empresa, permitindo confrontar metas planejadas com resultados realizados. Quando a organização cresce em complexidade societária ou geográfica, entram em ação a **Contabilidade Divisional (ou por Responsabilidade)**, que segrega resultados por centros de lucro ou unidades de negócio em empresas centralizadas, e a **Consolidação de Balanços**, que unifica as demonstrações de grupos econômicos compostos por empresas juridicamente independentes (Padoveze, 2010).',
          'No plano externo e estratégico, o SIC abrange ainda a **Análise Financeira, Padrões Setoriais e Concorrências**, incorporando indicadores de balanço e bases de dados sobre demonstrações anuais de concorrentes para avaliar o posicionamento competitivo da companhia, bem como a **Contabilidade Estratégica**, que instrumentaliza a controladoria no monitoramento de metas via *Balanced Scorecard* (BSC) e na gestão de riscos corporativos. Por último, Padoveze (2010) enfatiza a integração obrigatória com **Áreas Não Contábeis**: um SIC moderno precisa coletar e processar dados quantitativos físicos e operacionais — como volume de unidades produzidas, carteira de pedidos, número de empregados no RH e horas trabalhadas —, pois são esses indicadores não monetários que explicam a origem das variações patrimoniais.',
        ],
        infographics: [
          {
            id: 'abrangencia-subsistemas-sic',
            src: '/assets/aistudio/abrangencia-subsistemas-sic_aa32a295.png',
            title: 'Abrangência e Subsistemas do SIC',
            caption:
              'Conexão da Contabilidade Financeira no núcleo com os demais subsistemas, áreas operacionais e estratégia.',
            alt: 'Infográfico Abrangência e Subsistemas do SIC destacando a Contabilidade Financeira no núcleo integrada a Custos, Tributária, Orçamentos, Outras Moedas, Consolidação, Análise Financeira, Estratégica e Áreas Não Contábeis.',
            afterParagraphIndex: 3,
          },
        ],
      },
      {
        id: '1.4',
        slotKey: '1_4',
        code: '1.4',
        title: 'Características Qualitativas da Informação Contábil',
        paragraphs: [
          'Para que os relatórios extraídos do SIC cumpram sua finalidade decisória, não basta que os sistemas sejam tecnologicamente avançados; o conteúdo gerado precisa obedecer aos atributos qualitativos consagrados tanto na teoria contábil (Kieso, Weygandt & Warfield, 2001; Padoveze, 2010) quanto no **Pronunciamento Técnico CPC 00 (R2) — Estrutura Conceitual para Relatório Financeiro**. Como adverte Padoveze (2010), cada relatório deve ser planejado nos mínimos detalhes, pois estéticas inadequadas ou excesso de ruído informacional podem comprometer um excelente conteúdo técnico perante seu usuário final.',
          'No topo dessa estrutura situam-se as duas características qualitativas fundamentais: a **relevância** e a **representação fidedigna**. A informação contábil é relevante quando possui capacidade de fazer diferença nas decisões tomadas pelos usuários, o que ocorre quando ela apresenta **valor preditivo** (servindo de insumo para projetar fluxos de caixa futuros), **valor confirmatório** (validando ou corrigindo avaliações passadas) ou ambos, sempre balizada pelo limiar da **materialidade** (Kieso et al., 2001). Já a representação fidedigna exige que os relatórios retratem fielmente a essência econômica dos fenômenos que se propõem a representar, o que demanda três atributos simultâneos: ser **completa** (contendo todas as descrições e notas explicativas necessárias), **neutra** (isenta de viés na seleção ou apresentação dos dados) e **livre de erro** (sem falhas materiais no processo de coleta e processamento tecnológico).',
          'Potencializando a utilidade dessas duas bases, atuam quatro características qualitativas de melhoria. A **comparabilidade** permite que os usuários identifiquem semelhanças e diferenças entre dois conjuntos de fenômenos econômicos, seja comparando a mesma empresa ao longo de diferentes exercícios (consistência), seja confrontando empresas distintas do mesmo setor por meio de planos de contas padronizados. A **verificabilidade** assegura que diferentes observadores independentes e bem-informados possam chegar a um consenso de que determinada informação retrata fielmente a realidade — atributo que, nos sistemas modernos, é garantido pela vinculação digital entre o lançamento contábil e o documento fiscal originário (como o arquivo XML da NF-e ou o comprovante bancário autenticado).',
          'A **tempestividade** garante que a informação esteja disponível aos tomadores de decisão a tempo de poder influenciar suas escolhas, exigindo rotinas automatizadas de conciliação e fechamento contábil em tempo real. Por fim, a **compreensibilidade** determina que as informações sejam classificadas, caracterizadas e apresentadas com clareza e concisão. Embora se presuma que o usuário possua conhecimento razoável de negócios e contabilidade, o SIC deve evitar obscuridades técnicas desnecessárias, entregando demonstrações e painéis gerenciais claros, precisos e dirigidos ao perfil de cada decisor (Padoveze, 2010).',
        ],
      },
    ],
    references: [
      'ALVAREZ, Maria Esmeralda Ballestero. *Organização, sistemas e métodos*. São Paulo: McGraw-Hill, 1990.',
      'COMITÊ DE PRONUNCIAMENTOS CONTÁBEIS (CPC). *Pronunciamento Técnico CPC 00 (R2): Estrutura Conceitual para Relatório Financeiro*. Brasília, 2019.',
      'KIESO, Donald E.; WEYGANDT, Jerry J.; WARFIELD, Terry D. *Intermediate Accounting*. 10. ed. New York: John Wiley & Sons, 2001.',
      'PADOVEZE, Clóvis Luís. *Contabilidade gerencial: um enfoque em sistema de informação contábil*. 7. ed. São Paulo: Atlas, 2010.',
      'PADOVEZE, Clóvis Luís. *Sistemas de informações contábeis: fundamentos e análise*. São Paulo: Atlas, 2015.',
      'SOUZA, Antônio Artur de (Org.). *Sistemas de informação: fundamentos e aplicações*. Belo Horizonte: UFMG, 2015.',
    ],
    quiz: [
      {
        id: 'm1-q1',
        prompt:
          'Na arquitetura da pirâmide informacional aplicada ao Sistema de Informação Contábil (SIC), um analista financeiro identifica que o registro isolado `R$ 48.500,00` foi vinculado a uma duplicata vencida de um cliente específico e, com base no histórico de atrasos do setor, decide constituir uma perda estimada para créditos de liquidação duvidosa (PECLD). Respectivamente, os três estágios percorridos nessa análise correspondem a:',
        options: [
          'Informação, processamento e retroação (feedback).',
          'Dado, informação e conhecimento.',
          'Entrada física, sistema fechado e representação fidedigna.',
          'Conhecimento, dado contábil e eficácia operacional.',
        ],
        correctIndex: 1,
        explanation:
          'Segundo a hierarquia informacional descrita por Padoveze (2010), o valor bruto isolado (`R$ 48.500,00`) constitui o dado; sua contextualização como duplicata a receber de um cliente específico transforma-o em informação; e a aplicação da experiência técnica do contador para constituir a PECLD caracteriza o conhecimento aplicado à decisão.',
      },
      {
        id: 'm1-q2',
        prompt:
          'Quando o setor de almoxarifado registra a entrada física de mercadorias conferidas por Nota Fiscal Eletrônica (NF-e) e o SIC atualiza simultaneamente o estoque, gera o passivo no contas a pagar, apura créditos tributários e efetua o lançamento contábil sem redigitação manual, qual fundamento de validade perene do SIC e qual característica sistêmica estão sendo diretamente evidenciados?',
        options: [
          'Custo da informação e sistema fechado.',
          'Operacionalidade e materialidade restrita.',
          'Integração (base única de dados) e globalismo.',
          'Contabilidade divisional e verificabilidade indireta.',
        ],
        correctIndex: 2,
        explanation:
          'Para Padoveze (2010), a integração garante que todos os departamentos alimentem e consultem uma única base corporativa (*single source of truth*), eliminando redigitação e sistemas paralelos, o que concretiza o princípio sistêmico do globalismo, no qual uma ação em uma unidade repercute automaticamente em todo o sistema.',
      },
      {
        id: 'm1-q3',
        prompt:
          'Uma rede varejista pretende implementar um módulo adicional de rastreamento por código de barras e auditoria em tempo real exclusivo para lápis, clipes e blocos de anotação do escritório central, cujo custo anual de licenciamento e horas de analistas supera em cinco vezes o valor total desse estoque. À luz dos fundamentos de Padoveze (2010), por que esse projeto deve ser reprovado?',
        options: [
          'Porque viola o princípio do custo da informação, segundo o qual o custo de capturar, armazenar e processar um dado jamais deve superar o benefício decisório e econômico proporcionado.',
          'Porque a Contabilidade Financeira proíbe o controle de ativos imateriais em sistemas informatizados.',
          'Porque impede a aplicação da característica qualitativa da compreensibilidade nos relatórios societários.',
          'Porque itens de expediente pertencem exclusivamente à Contabilidade em Outras Moedas.',
        ],
        correctIndex: 0,
        explanation:
          'O fundamento do custo da informação estabelece uma restrição econômica racional ao SIC: o investimento financeiro e operacional exigido para produzir a informação não pode exceder o benefício econômico e decisório resultante para a entidade.',
      },
      {
        id: 'm1-q4',
        prompt:
          'Sobre a abrangência setorial e os subsistemas do SIC propostos por Padoveze (2010), assinale a alternativa que explica corretamente o papel da integração com Áreas Não Contábeis:',
        options: [
          'Substitui o plano de contas da Contabilidade Financeira em empresas industriais.',
          'Limita-se à conversão cambial de demonstrações financeiras de subsidiárias no exterior.',
          'Tem como única finalidade atender às obrigações acessórias enviadas aos sindicatos laborais.',
          'Coleta dados quantitativos físicos e operacionais — como unidades produzidas, carteira de pedidos e horas trabalhadas — que explicam a origem das variações patrimoniais.',
        ],
        correctIndex: 3,
        explanation:
          'Padoveze (2010) enfatiza que um SIC moderno precisa capturar indicadores físicos e operacionais de áreas não contábeis (produção, comercial, RH), pois esses dados não monetários fundamentam e explicam as variações patrimoniais registradas na contabilidade.',
      },
      {
        id: 'm1-q5',
        prompt:
          'De acordo com o Pronunciamento Técnico CPC 00 (R2) e a teoria contábil, um auditor independente consegue confirmar que o saldo da conta Fornecedores no balanço é fidedigno porque o SIC vincula diretamente cada lançamento contábil ao respectivo arquivo XML da NF-e e ao comprovante bancário autenticado. Esse vínculo tecnológico assegura primariamente a característica qualitativa de melhoria denominada:',
        options: [
          'Neutralidade preditiva.',
          'Verificabilidade.',
          'Consistência tributária.',
          'Materialidade operacional.',
        ],
        correctIndex: 1,
        explanation:
          'A verificabilidade (característica qualitativa de melhoria no CPC 00 R2) garante que diferentes observadores independentes possam alcançar consenso sobre a representação fidedigna de um fenômeno econômico, sendo operacionalizada nos sistemas pela vinculação digital direta entre o lançamento e o documento originário.',
      },
    ],
  },
  {
    id: 'mod-2',
    number: 2,
    title: 'Tipologia de Sistemas Corporativos e Análise de Dados',
    shortTitle: 'Sistemas Corporativos e Dados',
    description:
      'Arquitetura, parametrização e implantação de ERPs, Sistemas de Informação Gerencial (SIG), Sistemas de Apoio à Decisão (SAD) e os 5 Vs do Big Data aplicados à Contabilidade e Auditoria.',
    subtopics: [
      {
        id: '2.1',
        slotKey: '2_1',
        code: '2.1',
        title: 'Sistema de Gestão Empresarial (ERP — Enterprise Resource Planning)',
        paragraphs: [
          'Os sistemas integrados de gestão empresarial, conhecidos mundialmente como *Enterprise Resource Planning* (ERP), surgiram originalmente na década de 1970 a partir da evolução dos sistemas de planejamento de manufatura (MRP e MRP II), expandindo-se posteriormente para abarcar contabilidade, finanças, vendas, suprimentos e recursos humanos. Conforme definem Mancini e Prado (2022), o ERP é um sistema de informação computacional projetado para processar transações organizacionais e administrar fluxos de informações dentro e através da empresa de maneira *on-line* e em tempo real (*real time*). Sua essência arquitetônica reside na integração total dos processos internos por meio de um **banco de dados central único**: uma informação operacional é inserida no sistema apenas uma única vez no ponto de origem e torna-se imediatamente acessível a todos os demais módulos autorizados, eliminando interfaces manuais, redigitação e inconsistências cadastrais.',
          'Do ponto de vista técnico e funcional, os sistemas ERP distinguem-se dos softwares departamentais isolados por possuírem uma estrutura modular (permitindo que a empresa adquira e ative gradualmente módulos de finanças, contabilidade, estoque, manufatura ou RH), alta abrangência funcional e capacidade de implantação em diferentes ambientes operacionais com suporte multilíngue. Enquanto pacotes especialistas (*best of breed*) buscam profundidade máxima em uma única função isolada, o ERP prioriza a eficiência global da cadeia de valor interna, podendo ainda estender suas fronteiras externas mediante integração com sistemas de gestão da cadeia de suprimentos (SCM, voltado a fornecedores e logística) e de relacionamento com clientes (CRM, focado em pré-venda e pós-venda). Além disso, os ERPs incorporam modelos padronizados de processos de negócios (*best practices*), consolidados a partir da experiência de mercado de grandes fornecedores globais e nacionais, como **SAP** (líder entre grandes corporações), **TOTVS** (forte presença em pequenas e médias empresas brasileiras) e **Oracle** (Mancini & Prado, 2022).',
          'Para adequar essas práticas padronizadas às regras de negócio e às exigências tributárias de cada empresa, distinguem-se dois procedimentos técnicos fundamentais: a **parametrização** e a **customização**. A parametrização consiste no ajuste nativo de variáveis e tabelas internas já previstas pelo fabricante do *software* (como configurar alíquotas de ICMS, planos de contas ou regras de aprovação de pagamentos), sendo o caminho tecnicamente recomendado. Já a customização envolve a codificação de rotinas sob medida fora do padrão original do ERP; embora atenda a especificidades extremas, a customização deve ser minimizada ao máximo, pois eleva os custos de manutenção e gera sérios riscos de incompatibilidade quando a organização precisa atualizar o sistema para novas versões (Mancini & Prado, 2022).',
          'A implantação de um ERP representa um projeto organizacional complexo cuja transição para o ambiente produtivo denomina-se *go-live*. As empresas podem adotar três estratégias principais de transição: a substituição total simultânea (*Big Bang*), de alto risco operacional; a implantação por unidades organizacionais (iniciando por uma filial piloto); ou a implantação **baseada em funcionalidade**, que tradicionalmente começa pelo **departamento de Contabilidade** — justamente por ser o destino final de todas as transações econômicas da empresa — e migra gradativamente para os setores operacionais que originam os dados. Metodologicamente, o projeto percorre seis etapas: planejamento (definição de escopo e cronograma); análise de processos — dividida no mapeamento do cenário atual (*As-Is*), desenho do cenário futuro (*To-Be*) e levantamento de lacunas (*Gaps*) —; preparação do ambiente e treinamento; testes e instalação; migração dos dados legados (muitas vezes operando em paralelo temporariamente); e suporte pós-implantação. Apesar de trazer ganhos expressivos de agilidade, governança fiscal e redução de custos, a adoção de um ERP exige atenção aos altos investimentos envolvidos, à forte dependência do fornecedor, à perda de diferenciação competitiva causada pela padronização de processos e à necessidade de investir pesado no treinamento de usuários-chave (Mancini & Prado, 2022).',
        ],
        infographics: [
          {
            id: 'arquitetura-modular-erp',
            src: '/assets/aistudio/arquitetura-modular-erp.png_92fa0ee2.png',
            title: 'Arquitetura Modular de um ERP',
            caption:
              'Banco de dados centralizado em tempo real (Single Source of Truth) e integração contábil entre departamentos.',
            alt: 'Infográfico Arquitetura Modular de um ERP exibindo o banco de dados centralizado (Single Source of Truth) conectado aos módulos Financeiro, Fiscal, Vendas, Compras, RH, Produção e Contabilidade & Controladoria.',
            afterParagraphIndex: 1,
          },
        ],
      },
      {
        id: '2.2',
        slotKey: '2_2',
        code: '2.2',
        title: 'Sistema de Informação Gerencial (SIG)',
        paragraphs: [
          'Na arquitetura clássica dos sistemas corporativos estruturada sobre a pirâmide organizacional (Laudon & Laudon, 2014; Padoveze, 2015), enquanto os sistemas transacionais e o ERP operam na base operacional registrando o fluxo contínuo de compras, vendas e lançamentos diários, o **Sistema de Informação Gerencial (SIG)** posiciona-se no **nível tático ou gerencial**. Conceitualmente, o SIG corresponde ao que Padoveze (2010) denomina *Sistema de Informação de Apoio à Gestão*: um sistema que consome a massa de dados quantitativos e transacionais gerados pelos sistemas operacionais para consolidá-los, resumi-los e transformá-los em relatórios gerenciais estruturados voltados à supervisão, ao controle econômico-financeiro e à avaliação de desempenho setorial.',
          'A lógica de funcionamento do SIG é essencialmente comparativa, periódica e orientada ao controle. Ele responde a perguntas estruturadas como *"o que aconteceu no último mês?"* ou *"onde os custos reais se desviaram do planejamento?"*. Para isso, o SIG gera quatro categorias típicas de saída: relatórios programados (como balancetes mensais por centro de custo e demonstrações de resultado por filial), relatórios de exceção (que disparam alertas automáticos apenas quando um indicador ultrapassa limites críticos, como inadimplência acima de 5% ou estouro orçamentário), relatórios sob demanda e relatórios de indicadores-chave de desempenho (KPIs).',
          'No cotidiano da Controladoria e da Contabilidade Gerencial, o SIG é a ferramenta que permite ao *controller* confrontar o **Orçado versus Realizado** em tempo hábil. Se o ERP registra milhares de notas fiscais de insumos ao longo de trinta dias, o SIG sintetiza essas transações por departamento e aponta, por exemplo, que a unidade fabril consumiu 14% a mais de energia elétrica e matéria-prima do que o custo-padrão projetado, permitindo que o gerente de produção corrija o desvio operacional no ciclo seguinte sem precisar auditar lançamento por lançamento.',
        ],
        infographics: [
          {
            id: 'piramide-hierarquica-sistemas-sig',
            src: '/assets/aistudio/piramide-hierarquica-sistemas_c96908a5.png',
            title: 'Pirâmide Hierárquica dos Sistemas Corporativos',
            caption:
              'Integração entre os níveis Operacional (ERP), Tático (SIG) e Estratégico (SAD) na gestão empresarial.',
            alt: 'Infográfico Pirâmide Hierárquica dos Sistemas Corporativos demonstrando a integração entre ERP (nível operacional), SIG (nível tático) e SAD (nível estratégico).',
            afterParagraphIndex: 2,
          },
        ],
      },
      {
        id: '2.3',
        slotKey: '2_3',
        code: '2.3',
        title: 'Sistema de Apoio à Decisão (SAD)',
        paragraphs: [
          'Avançando em direção ao topo da pirâmide organizacional, encontra-se o **Sistema de Apoio à Decisão (SAD)**, posicionado no **nível estratégico** da gestão empresarial. Conforme aponta Padoveze (2015), o SAD constitui um refinamento dos sistemas de apoio à gestão, projetado especificamente para flexibilizar o tratamento de problemas semiestruturados ou não estruturados — aquelas decisões complexas, de alto impacto financeiro e longo prazo, para as quais não existe uma fórmula rotineira pré-definida. Enquanto o SIG olha para o retrovisor da organização por meio de relatórios padronizados, o SAD volta-se para o horizonte futuro por meio de modelagem matemática, análise estatística, simulação de cenários e ferramentas de *Business Intelligence* (BI) (Turban, Sharda & Delen, 2019).',
          'A característica distintiva do SAD é sua interatividade analítica baseada em consultas do tipo *"e se...?"* (*What-If Analysis*), análise de sensibilidade e busca de metas (*Goal-Seeking*). Para operar, o SAD extrai dados internos tanto da base transacional (ERP) quanto dos consolidados gerenciais (SIG), mas cruza essas informações com variáveis externas de mercado, tais como projeções de inflação, taxas de juros (Selic), variações cambiais, elasticidade de demanda e alterações na legislação tributária.',
          'Na prática financeira e contábil de alta gestão, um diretor financeiro (CFO) utiliza um SAD para conduzir um **planejamento tributário estratégico** ou analisar a viabilidade de um investimento de capital. Por meio do sistema, o contador pode simular simultaneamente o impacto no lucro líquido e no fluxo de caixa livre caso a companhia migre do regime de Lucro Presumido para o Lucro Real no próximo exercício, testando dezenas de cenários combinados de crescimento de receita, alteração na alíquota de tributos sobre o consumo e aumento no custo financeiro de captação de terceiros.',
        ],
        table: {
          title: 'Tabela Comparativa — Níveis Hierárquicos dos Sistemas Corporativos',
          headers: [
            'Dimensão Comparativa',
            'ERP / Nível Operacional',
            'SIG / Nível Tático',
            'SAD / Nível Estratégico',
          ],
          rows: [
            [
              '**Foco Principal**',
              'Execução e registro de transações rotineiras em tempo real.',
              'Controle gerencial, monitoramento de metas e avaliação setorial.',
              'Simulação de cenários, projeções e decisões complexas de longo prazo.',
            ],
            [
              '**Natureza dos Problemas**',
              'Estruturados e repetitivos (faturamento, folha, lançamentos).',
              'Estruturados e periódicos (análise de variações orçamentárias).',
              'Semiestruturados ou não estruturados (fusões, regime tributário).',
            ],
            [
              '**Fonte de Dados**',
              'Transações internas primárias inseridas na origem.',
              'Dados consolidados extraídos dos sistemas operacionais/ERP.',
              'Dados internos (ERP/SIG) cruzados com variáveis externas de mercado.',
            ],
            [
              '**Exemplo Contábil**',
              'Emissão de NF-e com contabilização automática de receita e estoque.',
              'Relatório mensal de *Orçado vs. Realizado* por centro de custos.',
              'Simulação *What-If* de impacto tributário e cambial no Lucro Líquido.',
            ],
          ],
        },
        infographics: [
          {
            id: 'piramide-hierarquica-sistemas-sad',
            src: '/assets/aistudio/piramide-hierarquica-sistemas_c96908a5.png',
            title: 'Pirâmide Hierárquica dos Sistemas Corporativos',
            caption:
              'Integração entre os níveis Operacional (ERP), Tático (SIG) e Estratégico (SAD) na gestão empresarial.',
            alt: 'Infográfico Pirâmide Hierárquica dos Sistemas Corporativos demonstrando o aumento da amplitude estratégica do ERP até o SAD e o detalhamento operacional na base.',
            afterParagraphIndex: 2,
          },
        ],
      },
      {
        id: '2.4',
        slotKey: '2_4',
        code: '2.4',
        title: 'Big Data e Analytics na Contabilidade (Conteúdo Extra Escolhido)',
        paragraphs: [
          'A explosão digital das transações comerciais, fiscais e financeiras superou a capacidade de armazenamento e processamento dos bancos de dados relacionais tradicionais, inaugurando a era do **Big Data**. Conforme sintetizam Mayer-Schönberger e Cukier (2013), o Big Data não se define apenas pelo tamanho colossal dos arquivos, mas pela capacidade analítica de extrair padrões, correlações e inteligência preditiva a partir de ecossistemas heterogêneos de dados. Na literatura contemporânea de sistemas de informação e contabilidade (Vasarhelyi, Kogan & Tuttle, 2015), esse fenômeno é estruturado conceitualmente sobre cinco dimensões interdependentes conhecidas como os **5 Vs do Big Data**.',
          'O primeiro pilar é o **Volume**, que diz respeito à escala massiva de registros gerados continuamente pelas organizações — abrangendo milhões de itens de notas fiscais eletrônicas (NF-e, NFC-e, CT-e), extratos bancários, transações de cartões e lançamentos contábeis acumulados ao longo dos anos. O segundo é a **Velocidade**, que reflete o ritmo acelerado com que esses dados são criados, transmitidos e processados em tempo real (*streaming*), exigindo que os sistemas contábeis abandonem o fechamento estático puramente mensal em favor do monitoramento contínuo. O terceiro é a **Variedade**, característica que rompe a barreira dos dados puramente numéricos e tabulares (dados estruturados): o Big Data contábil integra textos de contratos jurídicos em PDF, e-mails de negociação, gravações de atendimento, imagens de comprovantes e registros de *logs* de acesso (dados não estruturados e semiestruturados).',
          'Os dois últimos pilares asseguram a qualidade e o retorno econômico dessa arquitetura. A **Veracidade** trata da confiabilidade, limpeza, rastreabilidade e eliminação de ruídos ou inconsistências nas fontes de dados, fator crítico na Contabilidade, onde dados corrompidos invalidam demonstrações financeiras e geram autuações fiscais. Por fim, o **Valor** representa a capacidade efetiva de converter toda essa massa informacional bruta em vantagem competitiva, economia tributária lícita, prevenção de perdas ou precisão na avaliação de ativos.',
          'Na prática contábil e de auditoria, o Big Data transformou radicalmente tanto a fiscalização estatal quanto a atuação consultiva do contador. No âmbito tributário, o ambiente do Sistema Público de Escrituração Digital (SPED), integrado à e-Financeira e às declarações de operadoras de cartão, permite que a Receita Federal aplique algoritmos de cruzamento em tempo real sobre 100% das operações de contribuintes, identificando omissões de receita ou inconsistências de estoque em segundos. Paralelamente, na auditoria interna e independente, o Big Data viabiliza a **auditoria contínua**: em vez de examinar apenas uma pequena amostragem estatística de lançamentos ao final do ano, o auditor utiliza ferramentas de *Data Analytics* e técnicas estatísticas como a **Lei de Benford** para testar a população integral de registros contábeis, detectando anomalias ocultas, padrões atípicos de lançamentos manuais em horários suspeitos e riscos de insolvência antes mesmo que se materializem no balanço.',
        ],
        infographics: [
          {
            id: 'cinco-vs-big-data-contabilidade',
            src: '/assets/aistudio/cinco-vs-big-data-contabilidade_d334d589.png',
            title: 'Os 5 Vs do Big Data na Contabilidade',
            caption:
              'Volume, Velocidade, Variedade, Veracidade e Valor aplicados à auditoria contínua e ao cruzamento fiscal (SPED/e-Financeira).',
            alt: 'Infográfico Os 5 Vs do Big Data na Contabilidade apresentando Volume, Velocidade, Variedade, Veracidade e Valor conectados à Fiscalização Digital (SPED e e-Financeira) e à Auditoria Contínua (Lei de Benford).',
            afterParagraphIndex: 3,
          },
        ],
      },
    ],
    references: [
      'DAVENPORT, Thomas H. *Missão crítica: obtendo vantagem competitiva com os sistemas de gestão empresarial*. Porto Alegre: Bookman, 2002.',
      'LAUDON, Kenneth C.; LAUDON, Jane P. *Sistemas de informação gerenciais*. 11. ed. São Paulo: Pearson, 2014.',
      'MANCINI, Mônica; PRADO, Edmir Parada Vasques. Aplicações corporativas. In: MANCINI, Mônica; SOUZA-CONCILIO, Ilana (Orgs.). *Sistemas de informação: gestão e tecnologia na era digital*. Rio de Janeiro: Brasport, 2022.',
      'MAYER-SCHÖNBERGER, Viktor; CUKIER, Kenneth. *Big Data: como extrair volume, variedade, velocidade e valor da avalanche de informação cotidiana*. Rio de Janeiro: Elsevier, 2013.',
      'OLIVEIRA, Djalma de Pinho Rebouças de. *Sistemas de informações gerenciais*. São Paulo: Atlas, 2018.',
      'TURBAN, Efraim; SHARDA, Ramesh; DELEN, Dursun. *Business Intelligence e análise de dados para gestão do negócio*. 4. ed. Porto Alegre: Bookman, 2019.',
      'VASARHELYI, Miklos A.; KOGAN, Alexander; TUTTLE, Brad M. Big Data in Accounting: An Overview. *Accounting Horizons*, v. 29, n. 2, p. 381-396, 2015.',
    ],
    quiz: [
      {
        id: 'm2-q1',
        prompt:
          'Durante a implantação de um ERP para adequá-lo às alíquotas de ICMS, ao plano de contas e às alçadas de pagamento de uma indústria, a equipe de TI propõe codificar rotinas sob medida fora do código-fonte original, enquanto o controller defende o ajuste nativo de tabelas e variáveis já previstas pelo fabricante. Segundo Mancini e Prado (2022), a recomendação técnica do controller refere-se à:',
        options: [
          'Customização extensiva, que garante menor custo de atualização de versões futuras.',
          'Parametrização, procedimento tecnicamente recomendado por evitar incompatibilidades em atualizações e altos custos de manutenção.',
          'Transição Big Bang, que dispensa o mapeamento prévio de processos As-Is e To-Be.',
          'Substituição por softwares best of breed isolados sem banco de dados único.',
        ],
        correctIndex: 1,
        explanation:
          'Mancini e Prado (2022) distinguem parametrização (ajuste nativo de variáveis e tabelas previstas pelo fornecedor, tecnicamente recomendada) de customização (codificação sob medida fora do padrão, que deve ser minimizada por encarecer a manutenção e gerar incompatibilidade em atualizações).',
      },
      {
        id: 'm2-q2',
        prompt:
          'Na estratégia de implantação de um ERP baseada em funcionalidade, por qual setor as organizações tradicionalmente iniciam o projeto antes de migrar para as áreas operacionais de origem?',
        options: [
          'Pelo departamento de Contabilidade, por ser o destino final de todas as transações econômicas da empresa.',
          'Exclusivamente pelo setor de CRM de pós-venda.',
          'Pela expedição logística, visando isolar o fluxo de caixa do plano de contas.',
          'Pelo departamento de marketing digital, para testar variáveis externas de mercado.',
        ],
        correctIndex: 0,
        explanation:
          'Na implantação baseada em funcionalidade (Mancini & Prado, 2022), o projeto tradicionalmente começa pelo departamento de Contabilidade — destino final de todas as transações econômicas — e avança gradualmente para os setores operacionais que originam os dados.',
      },
      {
        id: 'm2-q3',
        prompt:
          'Um controller configura um relatório automático mensal que só dispara alertas quando a inadimplência de clientes ultrapassa 5% ou quando um centro de custo estoura o orçamento previsto em mais de 10%. Esse tipo de saída gerencial é típico de qual sistema corporativo e de qual categoria de relatório?',
        options: [
          'SAD — análise de sensibilidade tributária em ambiente externo.',
          'ERP — lançamento transacional primário em tempo real.',
          'SIG — relatório de exceção voltado ao controle gerencial no nível tático.',
          'Big Data — ingestão de contratos jurídicos em PDF não estruturados.',
        ],
        correctIndex: 2,
        explanation:
          'O Sistema de Informação Gerencial (SIG) atua no nível tático consolidando dados do ERP para controle e avaliação de desempenho. Entre suas quatro saídas típicas estão os relatórios de exceção, que emitem alertas apenas quando um indicador ultrapassa limites críticos definidos.',
      },
      {
        id: 'm2-q4',
        prompt:
          'O diretor financeiro (CFO) de um grupo empresarial precisa decidir se migra do Lucro Presumido para o Lucro Real no próximo exercício, simulando dezenas de cenários combinados com projeções da taxa Selic, câmbio e crescimento de receita. Qual sistema corporativo atende diretamente a essa necessidade?',
        options: [
          'Sistema de Apoio à Decisão (SAD), por tratar problemas semiestruturados ou não estruturados mediante análises What-If e cruzamento com variáveis externas.',
          'Sistema transacional de folha de pagamento, por operar exclusivamente com problemas repetitivos e estruturados.',
          'Relatório programado de balancete mensal do SIG, pois limita-se a olhar dados passados sem simulação.',
          'Módulo de almoxarifado do ERP, responsável pela emissão isolada de notas fiscais.',
        ],
        correctIndex: 0,
        explanation:
          'Posicionado no nível estratégico, o SAD é projetado para decisões complexas, semiestruturadas ou não estruturadas de longo prazo, utilizando simulações "e se...?" (What-If) e cruzando dados internos (ERP/SIG) com variáveis externas como juros, câmbio e tributação.',
      },
      {
        id: 'm2-q5',
        prompt:
          'No contexto de Big Data e Analytics aplicados à Contabilidade e Auditoria, ao substituir testes por pequenas amostras pela análise integral de 100% dos lançamentos contábeis com uso da Lei de Benford e cruzamento de PDFs de contratos, XMLs de NF-e e logs de acesso, quais conceitos se destacam?',
        options: [
          'Auditoria estática anual e redução do Volume para tabelas manuais isoladas.',
          'Variedade (dados estruturados e não estruturados), Veracidade e Auditoria Contínua sobre a população integral de registros.',
          'Exclusão da Veracidade em favor apenas da Velocidade de fechamento fiscal.',
          'Substituição completa das obrigações do SPED por arquivos impressos em papel.',
        ],
        correctIndex: 1,
        explanation:
          'O Big Data contábil integra dados estruturados e não estruturados (Variedade), exige dados limpos e rastreáveis (Veracidade) e viabiliza a auditoria contínua, na qual técnicas como Data Analytics e a Lei de Benford examinam 100% da população de lançamentos para detectar anomalias.',
      },
    ],
  },
  {
    id: 'mod-3',
    number: 3,
    title: 'Governança, Riscos e Conformidade (GRC)',
    shortTitle: 'Governança, Riscos e LGPD',
    description:
      'Estrutura integrada COSO de controle interno, controles preventivos/detectivos/corretivos, prevenção a fraudes (Triângulo da Fraude e NBC PG 01) e aplicação da LGPD na rotina contábil.',
    subtopics: [
      {
        id: '3.1',
        slotKey: '3_1',
        code: '3.1',
        title: 'Controle Interno e Segurança dos Sistemas Contábeis',
        paragraphs: [
          'A digitalização da Contabilidade, impulsionada por plataformas em nuvem, automação de processos e inteligência artificial, trouxe ganhos expressivos de produtividade e integração em tempo real, mas trouxe consigo vulnerabilidades inéditas, como invasões cibernéticas, adulteração eletrônica de registros e vazamento de dados estratégicos. Nesse contexto, o **Controle Interno** consolida-se como o alicerce da governança corporativa. Conforme definido pelo *Committee of Sponsoring Organizations of the Treadway Commission* (COSO, 2013) e aprofundado na literatura de auditoria por Attie (2022), o controle interno consiste em um sistema integrado de regras, procedimentos e rotinas conduzido pela administração e pelos colaboradores para proteger o patrimônio da entidade, assegurar a fidedignidade das informações contábeis e garantir a conformidade com leis e regulamentos.',
          'A metodologia internacional COSO (2013) estrutura o sistema de controle interno em cinco componentes inter-relacionados que devem permear tanto os processos humanos quanto a arquitetura tecnológica dos sistemas de informação:',
          'No plano técnico da Tecnologia da Informação aplicada à Contabilidade, as atividades de controle e segurança materializam-se em três camadas de proteção: controles **preventivos**, **detectivos** e **corretivos**. Os **controles preventivos** atuam antes que o erro ou a irregularidade ocorra, destacando-se a **segregação de funções** parametrizada no ERP — regra pela qual o usuário que cadastra um fornecedor não pode ser o mesmo que autoriza a compra, nem o que executa a baixa financeira. Somam-se a isso os perfis de acesso restrito por nível hierárquico, autenticação multifator e validações automáticas de campos obrigatórios.',
          'Os **controles detectivos**, por sua vez, identificam falhas ou manipulações que tenham superado as barreiras iniciais. Como ressalta Attie (2022), os **logs de auditoria** (trilhas eletrônicas imutáveis que registram exatamente qual usuário alterou, incluiu ou excluiu um registro, em qual data, horário e terminal) constituem uma das ferramentas antifraude mais eficazes da contabilidade moderna, ao lado das conciliações bancárias automatizadas e dos alertas de duplicidade de notas fiscais. Por fim, os **controles corretivos** asseguram a resiliência operacional após incidentes, englobando políticas de criptografia, rotinas automatizadas de *backup* redundante em nuvem e planos de continuidade de negócios. Quando uma empresa concede a um único analista contábil acesso irrestrito ao sistema sem segregação de funções nem revisão de *logs*, rompe-se a arquitetura do COSO e abre-se espaço imediato para distorções patrimoniais.',
        ],
        tableAfterParagraphIndex: 1,
        table: {
          title: 'Estrutura Integrada de Controle Interno — COSO (2013)',
          headers: [
            'Componente COSO (2013)',
            'Papel na Governança e Aplicação em Sistemas Contábeis',
          ],
          rows: [
            [
              '**Ambiente de Controle**',
              'Define o tom ético da alta administração, a cultura organizacional, a integridade e a estrutura formal de responsabilidades e hierarquia.',
            ],
            [
              '**Avaliação de Riscos**',
              'Processo contínuo de identificação e análise de ameaças operacionais, financeiras, cibernéticas e de *compliance*, mensurando probabilidade e impacto.',
            ],
            [
              '**Atividades de Controle**',
              'Políticas e travas técnicas que mitigam riscos na operação, como segregação de funções, alçadas de aprovação e restrição de acesso.',
            ],
            [
              '**Informação e Comunicação**',
              'Garante que relatórios confiáveis fluam entre os setores e mantém canais seguros de comunicação e denúncia interna.',
            ],
            [
              '**Monitoramento**',
              'Avaliação contínua da eficácia dos controles por meio de auditorias internas/externas, supervisão e alertas automatizados de sistema.',
            ],
          ],
        },
        infographics: [
          {
            id: 'triangulo-fraude-controle-interno-coso-31',
            src: '/assets/aistudio/triangulo-fraude-controle-interno-coso_20af61c4.png',
            title: 'Triângulo da Fraude vs. Controle Interno (COSO)',
            caption:
              'Camadas de proteção preventiva, detectiva e corretiva integradas à ética profissional (NBC PG 01) contra desvios.',
            alt: 'Infográfico Triângulo da Fraude vs. Controle Interno (COSO) conectando Pressão, Racionalização e Oportunidade às camadas de controles preventivos, detectivos, corretivos e ética profissional.',
            afterParagraphIndex: 3,
          },
        ],
      },
      {
        id: '3.2',
        slotKey: '3_2',
        code: '3.2',
        title: 'Fraude Contábil, Ética Profissional e Prevenção de Desvios',
        paragraphs: [
          'Na ciência contábil e nas normas de auditoria (NBC TA 240), é fundamental distinguir o **erro** — falha não intencional decorrente de desatenção, desconhecimento técnico ou interpretação equivocada — da **fraude**, definida por Silva (2019) como qualquer ato intencional de engano, omissão ou manipulação praticado com o objetivo deliberado de obter vantagem indevida ou causar prejuízo a terceiros. Com o advento dos sistemas informatizados, as fraudes tornaram-se mais sofisticadas e silenciosas, manifestando-se tanto na **apropriação indébita de ativos** (como desvios financeiros, criação de funcionários ou fornecedores "fantasmas" no ERP e pagamentos duplicados) quanto na **manipulação de demonstrações contábeis** (alteração direta de saldos no banco de dados, exclusão de registros de receitas ou superavaliação fictícia de ativos para enganar investidores e credores).',
          'Para compreender a anatomia desses desvios, a literatura forense recorre ao clássico **Triângulo da Fraude**, formulado pelo criminologista Donald Cressey, que aponta a convergência de três fatores: a **pressão** (necessidade financeira pessoal ou metas corporativas inatingíveis), a **racionalização** (justificativa moral que o fraudador cria para legitimar o ato ilícito) e a **oportunidade** (brecha nos controles internos e nos sistemas de TI que permite executar e ocultar a fraude sem ser descoberto). Enquanto a pressão e a racionalização pertencem à esfera psicológica do indivíduo, a **oportunidade** é diretamente neutralizada pelo desenho rigoroso dos controles internos e da segurança da informação (Wells, 2015).',
          'Além das barreiras tecnológicas — como o cruzamento automatizado entre o cadastro de sócios de fornecedores e o banco de dados de colaboradores do RH para barrar empresas de fachada, ou a proteção contra ataques externos de *phishing* e *malware* —, a prevenção de desvios depende do fator humano e deontológico. Como enfatiza Crepaldi (2020), a ética não é um acessório, mas a própria essência da confiabilidade da informação contábil. O **Código de Ética Profissional do Contador (NBC PG 01)** impõe ao profissional o dever inegociável de zelar pela integridade, objetividade, sigilo profissional e uso ético dos softwares e bases de dados corporativos. Assim, o contador deixa de ser um mero operador técnico de sistemas para atuar como um verdadeiro agente de governança, ética e prevenção contra fraudes nas organizações.',
        ],
        infographics: [
          {
            id: 'triangulo-fraude-controle-interno-coso-32',
            src: '/assets/aistudio/triangulo-fraude-controle-interno-coso_20af61c4.png',
            title: 'Triângulo da Fraude vs. Controle Interno (COSO)',
            caption:
              'Camadas de proteção preventiva, detectiva e corretiva integradas à ética profissional (NBC PG 01) contra desvios.',
            alt: 'Infográfico Triângulo da Fraude vs. Controle Interno (COSO) ilustrando como controles preventivos, detectivos, corretivos e a ética profissional (NBC PG 01) neutralizam a oportunidade de fraude.',
            afterParagraphIndex: 2,
          },
        ],
      },
      {
        id: '3.3',
        slotKey: '3_3',
        code: '3.3',
        title: 'LGPD na Contabilidade (Lei nº 13.709/2018)',
        paragraphs: [
          'A entrada em vigor da **Lei Geral de Proteção de Dados Pessoais (Lei nº 13.709/2018 — LGPD)** trouxe impactos profundos para a rotina dos escritórios de contabilidade e departamentos contábeis internos. Diferentemente de outros setores que lidam apenas com dados cadastrais comerciais, a Contabilidade é um ambiente de altíssima densidade de **dados pessoais** (nome, CPF, endereço, dados bancários de sócios, clientes e empregados) e de **dados pessoais sensíveis** (informações de saúde em atestados médicos e exames ocupacionais do eSocial, filiação sindical na folha de pagamento e dados biométricos de controle de ponto), conforme analisam Maldonado e Blum (2019).',
          'Para aplicar corretamente a LGPD na prática contábil, é indispensável delimitar os papéis jurídicos dos agentes de tratamento definidos pela lei. Na relação terceirizada típica, a empresa cliente que contrata os serviços contábeis figura como **Controladora**, pois é ela quem toma as decisões referentes ao propósito e à necessidade do tratamento dos dados de seus empregados e clientes. O escritório de contabilidade, por sua vez, atua predominantemente como **Operador**, realizando o processamento da folha de pagamento, das obrigações acessórias e da escrituração fiscal em nome e segundo as diretrizes do controlador — embora o escritório também assuma a posição de Controlador em relação aos dados de seus próprios funcionários e fornecedores. Ambos devem cooperar com o **Encarregado pelo Tratamento de Dados Pessoais (DPO)** e respondem solidariamente caso causem danos patrimoniais ou morais por descumprimento das normas de segurança.',
          'Um equívoco frequente no meio empresarial consiste em supor que o contador precisa colher termo de consentimento individual para processar cada documento. Na verdade, o Art. 7º da LGPD estabelece dez bases legais autônomas, e a atividade contábil sustenta-se prioritariamente no **cumprimento de obrigação legal ou regulatória pelo controlador** e na **execução de contrato**. Por força dessa base legal, se um ex-empregado solicitar a exclusão imediata de todos os seus dados pessoais do sistema do escritório contábil logo após sua demissão, o contador não deve — e legalmente não pode — apagar tais registros imediatamente, pois a legislação trabalhista, previdenciária e tributária impõe prazos obrigatórios de guarda documental (que variam de cinco a mais de vinte anos para fins de FGTS, INSS e fiscalizações do eSocial).',
          'Contudo, a dispensa do consentimento não reduz a exigência rigorosa de **segurança da informação e governança técnica** prevista no Art. 46 da LGPD. Escritórios e departamentos contábeis devem adotar medidas técnicas e administrativas aptas a proteger os dados contra acessos não autorizados e vazamentos acidentais ou ilícitos — o que inclui criptografia em repouso e em trânsito, eliminação do envio desprotegido de holerites e declarações de Imposto de Renda por aplicativos de mensagens sem senha, controle rigoroso de permissões de acesso nos sistemas contábeis e política formal de descarte seguro após o término do prazo legal de retenção.',
        ],
        infographics: [
          {
            id: 'lgpd-na-contabilidade',
            src: '/assets/aistudio/lgpd-na-contabilidade_8be96103.png',
            title: 'LGPD na Contabilidade (Lei nº 13.709/2018)',
            caption:
              'Papéis de Titular, Controlador e Operador, base legal do cumprimento de obrigação legal (Art. 7º) e segurança técnica (Art. 46).',
            alt: 'Infográfico LGPD na Contabilidade detalhando Titular dos Dados, Controlador (empresa cliente), Operador (escritório contábil), Base Legal Principal do Art. 7º e Segurança Técnica do Art. 46.',
            afterParagraphIndex: 3,
          },
        ],
      },
    ],
    references: [
      'ATTIE, William. *Auditoria: conceitos e aplicações*. 8. ed. São Paulo: Atlas, 2022.',
      'BRASIL. *Lei nº 13.709, de 14 de agosto de 2018 (Lei Geral de Proteção de Dados Pessoais — LGPD)*. Brasília, 2018.',
      'CONSELHO FEDERAL DE CONTABILIDADE (CFC). *Norma Brasileira de Contabilidade NBC PG 01 — Código de Ética Profissional do Contador*. Brasília, 2019.',
      'COSO — *Committee of Sponsoring Organizations of the Treadway Commission*. *Controle Interno — Estrutura Integrada*. 2013.',
      'CREPALDI, Silvio Aparecido. *Auditoria contábil: teoria e prática*. 11. ed. São Paulo: Atlas, 2020.',
      'MALDONADO, Viviane Nóbrega; BLUM, Renato Opice (Coords.). *LGPD: Lei Geral de Proteção de Dados Comentada*. São Paulo: Thomson Reuters Brasil, 2019.',
      'SILVA, Lourivaldo Lopes da. *Contabilidade geral e tributária*. São Paulo: IOB, 2019.',
      'WELLS, Joseph T. *Manual da fraude na empresa: prevenção e detecção*. São Paulo: Editora Brasileira, 2015.',
    ],
    quiz: [
      {
        id: 'm3-q1',
        prompt:
          'Em uma auditoria de sistemas no ERP de uma empresa comercial, constata-se que o mesmo colaborador consegue cadastrar novos fornecedores, aprovar pedidos de compra e efetuar a baixa financeira dos pagamentos no contas a pagar. À luz da metodologia COSO (2013) e das camadas de controle de TI, qual falha crítica foi identificada?',
        options: [
          'Ausência de controle preventivo por violação direta à segregação de funções nas atividades de controle.',
          'Falha exclusiva do controle corretivo de backup em nuvem.',
          'Excesso de controle detectivo sobre conciliações bancárias automatizadas.',
          'Descumprimento da obrigatoriedade de consentimento individual na LGPD.',
        ],
        correctIndex: 0,
        explanation:
          'A segregação de funções é um controle preventivo fundamental nas atividades de controle do COSO (2013): impede que o mesmo usuário cadastre um fornecedor, autorize a compra e execute o pagamento, mitigando o risco de fornecedores fantasmas e desvios financeiros.',
      },
      {
        id: 'm3-q2',
        prompt:
          'Para rastrear quem alterou ou excluiu um lançamento contábil após o encerramento mensal — identificando usuário, data, horário e terminal —, a auditoria recorre às trilhas eletrônicas imutáveis do sistema. Segundo Attie (2022), os logs de auditoria classificam-se como:',
        options: [
          'Controles preventivos de ambiente ético.',
          'Controles detectivos voltados à identificação de falhas ou manipulações.',
          'Controles corretivos de criptografia de holerites.',
          'Instrumentos de planejamento tributário no nível estratégico.',
        ],
        correctIndex: 1,
        explanation:
          'Como destaca Attie (2022), os logs de auditoria (ao lado das conciliações automatizadas e alertas de duplicidade) são controles detectivos essenciais para identificar alterações indevidas que tenham ocorrido nos registros eletrônicos.',
      },
      {
        id: 'm3-q3',
        prompt:
          'Segundo o Triângulo da Fraude de Donald Cressey (Wells, 2015), qual dos três vértices é diretamente neutralizado pela implementação rigorosa de controles internos, segregação de funções e segurança dos sistemas de TI?',
        options: [
          'A pressão financeira pessoal do colaborador.',
          'A racionalização moral elaborada pelo fraudador.',
          'A oportunidade decorrente de brechas nos controles internos e sistemas.',
          'O erro contábil não intencional previsto na NBC TA 240.',
        ],
        correctIndex: 2,
        explanation:
          'Enquanto a pressão e a racionalização pertencem à esfera psicológica individual, a oportunidade — brecha nos controles internos e na TI que permite praticar e ocultar o desvio — é diretamente combatida pelo desenho rigoroso dos controles e da governança de sistemas.',
      },
      {
        id: 'm3-q4',
        prompt:
          'Um ex-empregado de uma empresa cliente aciona o escritório de contabilidade terceirizado exigindo a exclusão imediata de seus registros da folha de pagamento e dos eventos do eSocial logo após a rescisão contratual. Considerando a Lei nº 13.709/2018 (LGPD), como o contador deve proceder?',
        options: [
          'Excluir todos os registros no mesmo dia, pois o consentimento foi revogado pelo titular.',
          'Recusar a exclusão imediata dos registros sujeitos a guarda legal, pois o tratamento fundamenta-se na base legal de cumprimento de obrigação legal ou regulatória (prazos trabalhistas, previdenciários e fiscais).',
          'Transferir a responsabilidade exclusivamente ao sindicato, já que dados trabalhistas não se enquadram na LGPD.',
          'Publicar os dados em portal aberto para comprovar transparência como Controlador.',
        ],
        correctIndex: 1,
        explanation:
          'A atividade contábil apoia-se prioritariamente nas bases legais de cumprimento de obrigação legal ou regulatória e execução de contrato (Art. 7º da LGPD). Como a legislação trabalhista, previdenciária e tributária exige guarda documental por vários anos (FGTS, INSS, eSocial), o contador não pode apagar esses registros imediatamente.',
      },
      {
        id: 'm3-q5',
        prompt:
          'Na prestação de serviços contábeis terceirizados sob a ótica da LGPD (Maldonado & Blum, 2019), ao processar a folha de pagamento e os atestados médicos ocupacionais (dados sensíveis) seguindo as diretrizes da empresa cliente que determinou a finalidade do tratamento, qual papel jurídico o escritório de contabilidade exerce predominantemente?',
        options: [
          'Titular dos dados pessoais sensíveis.',
          'Agente regulador exclusivo da ANPD.',
          'Operador em relação aos dados dos empregados da empresa cliente, assumindo o papel de Controlador apenas quanto aos dados de seus próprios funcionários e fornecedores.',
          'Usuário externo com interesse indireto dispensado das exigências técnicas do Art. 46.',
        ],
        correctIndex: 2,
        explanation:
          'Na relação terceirizada típica, a empresa contratante é a Controladora (toma as decisões sobre o tratamento), enquanto o escritório contábil atua predominantemente como Operador ao processar folha e obrigações em nome da cliente — mantendo o dever de segurança técnica do Art. 46 e respondendo solidariamente em caso de danos por descumprimento.',
      },
    ],
  },
];
