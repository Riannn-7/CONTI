import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import type { InfographicItem } from '../types/course';

interface InfographicLightboxProps {
  infographic: InfographicItem | null;
  onClose: () => void;
}

export const InfographicLightbox: React.FC<InfographicLightboxProps> = ({
  infographic,
  onClose,
}) => {
  useEffect(() => {
    if (!infographic) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [infographic, onClose]);

  if (!infographic) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#030B26]/92 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="infographic-lightbox-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-6xl max-h-[94vh] rounded-2xl bg-[#0A163D] border border-[#00B4FF]/35 shadow-2xl shadow-black/75 flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3.5 bg-[#0F1E4E] border-b conti-border flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2
              id="infographic-lightbox-title"
              className="text-sm sm:text-base font-display font-bold text-white truncate"
            >
              {infographic.title}
            </h2>
            <p className="text-xs text-[#CBD5E1] truncate mt-0.5">
              {infographic.caption}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar visualização ampliada"
            className="shrink-0 w-10 h-10 rounded-lg bg-[#0A163D] border conti-border text-[#E2E8F0] hover:text-white hover:border-[#00B4FF] flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-3 sm:p-5 bg-[#030B26] flex items-center justify-center">
          <img
            src={infographic.src}
            alt={infographic.alt}
            referrerPolicy="no-referrer"
            className="max-w-full max-h-[78vh] w-auto h-auto object-contain rounded-lg"
          />
        </div>
      </div>
    </div>
  );
};
