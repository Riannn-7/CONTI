import React from 'react';

interface ContiLogoProps {
  showSubtitle?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const ContiLogo: React.FC<ContiLogoProps> = ({
  showSubtitle = false,
  size = 'md',
}) => {
  const iconDimensions =
    size === 'lg' ? 'w-12 h-12' : size === 'sm' ? 'w-8 h-8' : 'w-10 h-10';
  const titleSize =
    size === 'lg' ? 'text-2xl sm:text-3xl' : size === 'sm' ? 'text-lg' : 'text-xl';

  return (
    <div className="flex items-center gap-3.5 min-w-0">
      <svg
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${iconDimensions} shrink-0`}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="contiLayerTop" x1="8" y1="6" x2="56" y2="28" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00B4FF" />
            <stop offset="100%" stopColor="#4F46E5" />
          </linearGradient>
          <linearGradient id="contiLayerMid" x1="8" y1="22" x2="56" y2="44" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00B4FF" stopOpacity="0.88" />
            <stop offset="100%" stopColor="#4F46E5" stopOpacity="0.92" />
          </linearGradient>
          <linearGradient id="contiLayerBot" x1="8" y1="36" x2="56" y2="58" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00B4FF" stopOpacity="0.65" />
            <stop offset="100%" stopColor="#4F46E5" stopOpacity="0.78" />
          </linearGradient>
        </defs>

        {/* Camada inferior (Base contábil) */}
        <path
          d="M32 36L56 47L32 58L8 47L32 36Z"
          fill="url(#contiLayerBot)"
          stroke="#00B4FF"
          strokeOpacity="0.45"
          strokeWidth="1.2"
          strokeLinejoin="round"
        />
        {/* Camada intermediária (Processamento e sistemas) */}
        <path
          d="M32 22L56 33L32 44L8 33L32 22Z"
          fill="url(#contiLayerMid)"
          stroke="#38BDF8"
          strokeOpacity="0.7"
          strokeWidth="1.2"
          strokeLinejoin="round"
        />
        {/* Camada superior (Informação e decisão) */}
        <path
          d="M32 8L56 19L32 30L8 19L32 8Z"
          fill="url(#contiLayerTop)"
          stroke="#E0F2FE"
          strokeOpacity="0.85"
          strokeWidth="1.3"
          strokeLinejoin="round"
        />
      </svg>

      <div className="min-w-0">
        <div
          className={`${titleSize} font-display font-extrabold tracking-tight text-white leading-none whitespace-nowrap`}
        >
          CONTI
        </div>
        {showSubtitle && (
          <p className="mt-1 text-xs sm:text-sm text-[#94A3B8] font-medium tracking-wide leading-snug">
            <span className="text-[#00B4FF] font-semibold">TECNOLOGIA E INFORMAÇÃO</span>
            <span aria-hidden="true"> — </span>
            <span className="text-[#E2E8F0]">Conhecimento que conecta.</span>
          </p>
        )}
      </div>
    </div>
  );
};
