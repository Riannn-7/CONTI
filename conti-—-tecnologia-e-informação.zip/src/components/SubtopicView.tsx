import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BookMarked,
  Check,
  CheckCircle2,
  ClipboardCheck,
  Gamepad2,
} from 'lucide-react';
import type { CourseModule, InfographicItem, Subtopic } from '../types/course';
import { AcademicTable, renderFormattedText } from './RichText';
import { InfographicCard } from './InfographicCard';
import { InfographicLightbox } from './InfographicLightbox';

interface SubtopicViewProps {
  module: CourseModule;
  subtopic: Subtopic;
  isStudied: boolean;
  prevSubtopic: { moduleId: string; subtopic: Subtopic } | null;
  nextSubtopic: { moduleId: string; subtopic: Subtopic } | null;
  isLastInModule: boolean;
  onToggleStudied: (subtopicId: string) => void;
  onOpenGame: (subtopic: Subtopic) => void;
  onNavigateSubtopic: (moduleId: string, subtopicId: string) => void;
  onNavigateQuiz: (moduleId: string) => void;
}

export const SubtopicView: React.FC<SubtopicViewProps> = ({
  module,
  subtopic,
  isStudied,
  prevSubtopic,
  nextSubtopic,
  isLastInModule,
  onToggleStudied,
  onOpenGame,
  onNavigateSubtopic,
  onNavigateQuiz,
}) => {
  const [expandedInfographic, setExpandedInfographic] = useState<InfographicItem | null>(null);
  const insertTableAfterIndex =
    typeof subtopic.tableAfterParagraphIndex === 'number'
      ? subtopic.tableAfterParagraphIndex
      : subtopic.paragraphs.length - 1;

  const renderStudiedButton = (position: 'top' | 'bottom') => (
    <button
      type="button"
      data-testid={`mark-studied-btn-${position}`}
      onClick={() => onToggleStudied(subtopic.id)}
      aria-pressed={isStudied}
      className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-sm font-display font-semibold border transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#10B981] ${
        isStudied
          ? 'bg-[#10B981] border-[#10B981] text-[#030B26] hover:bg-[#10B981]/90 shadow-lg shadow-[#10B981]/20'
          : 'bg-[#0F1E4E] border-[#00B4FF]/40 text-white hover:border-[#00B4FF] hover:bg-[#0F1E4E]/90'
      }`}
    >
      {isStudied ? (
        <>
          <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Conteúdo Estudado ✓</span>
        </>
      ) : (
        <>
          <Check className="w-4 h-4 shrink-0 text-[#00B4FF]" aria-hidden="true" />
          <span>Marcar conteúdo como estudado</span>
        </>
      )}
    </button>
  );

  return (
    <article className="max-w-4xl mx-auto px-5 sm:px-10 py-8 sm:py-10">
      {/* Cabeçalho do Subtópico */}
      <header className="pb-6 mb-8 border-b conti-border">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div className="min-w-0">
            <p className="text-xs sm:text-sm font-medium text-[#00B4FF] mb-2">
              Módulo {module.number} · {module.title}
            </p>
            <h1 className="text-2xl sm:text-3xl font-display font-bold text-white leading-tight [text-wrap:balance]">
              <span className="font-mono text-[#00B4FF] mr-2 tabular-nums">
                {subtopic.code}
              </span>
              {subtopic.title}
            </h1>
          </div>

          <div className="shrink-0">{renderStudiedButton('top')}</div>
        </div>
      </header>

      {/* Conteúdo Dissertativo Integral e Infográficos */}
      <div className="conti-prose space-y-6">
        {subtopic.paragraphs.map((paragraph, index) => {
          const matchingInfographics = (subtopic.infographics ?? []).filter(
            (item) => item.afterParagraphIndex === index
          );
          return (
            <React.Fragment key={index}>
              <p className="max-w-[72ch]">{renderFormattedText(paragraph)}</p>
              {subtopic.table && index === insertTableAfterIndex && (
                <AcademicTable table={subtopic.table} />
              )}
              {matchingInfographics.map((infographic) => (
                <InfographicCard
                  key={infographic.id}
                  infographic={infographic}
                  onExpand={setExpandedInfographic}
                />
              ))}
            </React.Fragment>
          );
        })}
      </div>

      {/* Botão de Marcação no Rodapé da Leitura */}
      <div className="mt-10 pt-6 border-t conti-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <p className="text-sm text-[#94A3B8]">
          {isStudied
            ? 'Este subtópico já foi registrado no seu progresso de estudos.'
            : 'Concluiu a leitura? Registre este subtópico no seu histórico de estudos.'}
        </p>
        {renderStudiedButton('bottom')}
      </div>

      {/* Cartão de Jogo Interativo do Subtópico */}
      <section
        aria-labelledby="subtopic-game-card-title"
        className="mt-10 rounded-2xl bg-[#0A163D] border conti-border p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-6"
      >
        <div className="min-w-0">
          <p className="text-xs font-semibold text-[#00B4FF] mb-1.5">
            Prática Aplicada do Subtópico {subtopic.code}
          </p>
          <h2
            id="subtopic-game-card-title"
            className="text-lg font-display font-bold text-white mb-1.5"
          >
            Fixação Interativa dos Conceitos
          </h2>
          <p className="text-sm text-[#CBD5E1] leading-relaxed">
            Acesse o módulo de desafio prático preparado para consolidar os conceitos de{' '}
            <span className="text-white font-medium">{subtopic.title}</span> na rotina contábil.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onOpenGame(subtopic)}
          className="conti-gradient text-white font-display font-semibold text-sm py-3 px-5 rounded-xl inline-flex items-center justify-center gap-2.5 hover:opacity-95 transition-opacity whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
        >
          <Gamepad2 className="w-5 h-5 shrink-0" aria-hidden="true" />
          <span>Jogar e Testar Conhecimentos deste Subtópico</span>
        </button>
      </section>

      {/* Referências Bibliográficas do Módulo */}
      <section
        aria-labelledby="module-references-heading"
        className="mt-10 rounded-2xl bg-[#0A163D]/60 border conti-border p-6"
      >
        <div className="flex items-center gap-2.5 mb-4">
          <BookMarked className="w-4 h-4 text-[#00B4FF]" aria-hidden="true" />
          <h2
            id="module-references-heading"
            className="text-sm font-display font-bold text-white"
          >
            Referências Bibliográficas do Módulo {module.number}
          </h2>
        </div>
        <ul className="divide-y divide-[rgba(0,180,255,0.12)] text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
          {module.references.map((ref, idx) => (
            <li key={idx} className="py-2 first:pt-0 last:pb-0">
              {renderFormattedText(ref)}
            </li>
          ))}
        </ul>
      </section>

      {/* Navegação Sequencial */}
      <nav
        aria-label="Navegação entre subtópicos"
        className="mt-10 pt-6 border-t conti-border flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3"
      >
        {prevSubtopic ? (
          <button
            type="button"
            onClick={() =>
              onNavigateSubtopic(prevSubtopic.moduleId, prevSubtopic.subtopic.id)
            }
            className="py-3 px-4 rounded-xl bg-[#0A163D] border conti-border text-left hover:border-[#00B4FF] transition-colors flex items-center gap-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
          >
            <ArrowLeft className="w-4 h-4 text-[#00B4FF] shrink-0" aria-hidden="true" />
            <div className="min-w-0">
              <span className="block text-[11px] text-[#94A3B8]">Anterior</span>
              <span className="block text-xs sm:text-sm font-semibold text-white truncate max-w-[240px]">
                {prevSubtopic.subtopic.code} {prevSubtopic.subtopic.title}
              </span>
            </div>
          </button>
        ) : (
          <div />
        )}

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {isLastInModule && (
            <button
              type="button"
              onClick={() => onNavigateQuiz(module.id)}
              className="conti-gradient py-3 px-5 rounded-xl text-sm font-display font-semibold text-white inline-flex items-center justify-center gap-2 hover:opacity-95 transition-opacity whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <ClipboardCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Ir para Atividade Avaliativa</span>
            </button>
          )}

          {nextSubtopic && (
            <button
              type="button"
              onClick={() =>
                onNavigateSubtopic(nextSubtopic.moduleId, nextSubtopic.subtopic.id)
              }
              className="py-3 px-4 rounded-xl bg-[#0A163D] border conti-border text-right hover:border-[#00B4FF] transition-colors flex items-center justify-end gap-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <div className="min-w-0">
                <span className="block text-[11px] text-[#94A3B8]">Próximo</span>
                <span className="block text-xs sm:text-sm font-semibold text-white truncate max-w-[240px]">
                  {nextSubtopic.subtopic.code} {nextSubtopic.subtopic.title}
                </span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#00B4FF] shrink-0" aria-hidden="true" />
            </button>
          )}
        </div>
      </nav>

      <InfographicLightbox
        infographic={expandedInfographic}
        onClose={() => setExpandedInfographic(null)}
      />
    </article>
  );
};
