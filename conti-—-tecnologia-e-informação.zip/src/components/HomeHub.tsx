import React from 'react';
import {
  ArrowRight,
  BookOpen,
  Check,
  CheckCircle2,
  ClipboardCheck,
  GraduationCap,
} from 'lucide-react';
import type { CourseModule, PersistedProgress } from '../types/course';
import {
  getModuleCompletionStats,
  getOverallProgress,
  isSubtopicStudied,
} from '../utils/progress';
import { ContiLogo } from './ContiLogo';

interface HomeHubProps {
  modules: CourseModule[];
  progress: PersistedProgress;
  onOpenModule: (moduleId: string, subtopicId?: string) => void;
  onOpenQuiz: (moduleId: string) => void;
}

export const HomeHub: React.FC<HomeHubProps> = ({
  modules,
  progress,
  onOpenModule,
  onOpenQuiz,
}) => {
  const overall = getOverallProgress(progress, modules);

  return (
    <div className="min-h-screen bg-[#030B26] text-[#E2E8F0] flex flex-col">
      {/* Cabeçalho Oficial CONTI */}
      <header className="border-b conti-border bg-[#0A163D]/70 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-5 sm:px-8 py-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <ContiLogo showSubtitle size="lg" />

          <div className="flex items-center gap-4 text-xs sm:text-sm text-[#94A3B8] shrink-0">
            <span className="inline-flex items-center gap-1.5 text-[#E2E8F0] font-medium">
              <GraduationCap className="w-4 h-4 text-[#00B4FF]" aria-hidden="true" />
              Ciências Contábeis · TI
            </span>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-5 sm:px-8 py-8 sm:py-12">
        {/* Apresentação Acadêmica + Progresso Geral */}
        <section
          aria-labelledby="hub-intro-heading"
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-10 sm:mb-12"
        >
          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs sm:text-sm font-medium text-[#00B4FF] mb-2">
              Plataforma Universitária de Estudos
            </p>
            <h1
              id="hub-intro-heading"
              className="text-2xl sm:text-4xl font-display font-bold text-white leading-tight tracking-tight mb-4 [text-wrap:balance]"
            >
              Tecnologia da Informação aplicada à Prática Contábil
            </h1>
            <p className="text-base leading-relaxed text-[#CBD5E1] max-w-2xl">
              Ambiente acadêmico desenvolvido por estudantes de graduação em Ciências Contábeis
              para conectar os fundamentos dos Sistemas de Informação à escrituração fiscal,
              controladoria, auditoria contínua e governança corporativa. Selecione um módulo
              abaixo para iniciar a leitura integral, testar conhecimentos e realizar a avaliação.
            </p>
          </div>

          <div className="lg:col-span-5 rounded-2xl bg-[#0A163D] border conti-border p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-3 mb-3">
                <h2 className="text-sm font-display font-semibold text-white">
                  Progresso Geral dos Estudos
                </h2>
                <span
                  data-testid="overall-progress-percent"
                  className={`text-xl font-display font-bold tabular-nums ${
                    overall.percent === 100 ? 'text-[#10B981]' : 'text-[#00B4FF]'
                  }`}
                >
                  {overall.percent}%
                </span>
              </div>

              {/* Barra de Progresso */}
              <div
                className="w-full h-3 rounded-full bg-[#030B26] border border-[rgba(0,180,255,0.18)] overflow-hidden mb-3"
                role="progressbar"
                aria-valuenow={overall.percent}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="Progresso geral de estudos"
              >
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    overall.completed > 0 ? 'bg-[#10B981]' : 'bg-[#00B4FF]'
                  }`}
                  style={{ width: `${overall.percent}%` }}
                />
              </div>

              <p
                data-testid="overall-progress-count"
                className="text-sm text-[#CBD5E1] tabular-nums"
              >
                <strong className="text-white font-semibold">{overall.completed}</strong> de{' '}
                <strong className="text-white font-semibold">{overall.total}</strong> subtópicos
                concluídos
                <span aria-hidden="true"> · </span>
                <span>
                  {overall.completedModules} de {modules.length} módulos completos
                </span>
              </p>
            </div>

            <div className="mt-6 pt-4 border-t conti-border flex items-center justify-between gap-3 text-xs text-[#94A3B8]">
              <span>Progresso salvo automaticamente no navegador</span>
              {overall.completed === overall.total && overall.total > 0 && (
                <span className="inline-flex items-center gap-1 text-[#10B981] font-semibold whitespace-nowrap">
                  <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                  Curso concluído
                </span>
              )}
            </div>
          </div>
        </section>

        {/* Grade dos 3 Módulos Principais */}
        <section aria-labelledby="modules-grid-heading">
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-6">
            <h2
              id="modules-grid-heading"
              className="text-xl sm:text-2xl font-display font-bold text-white"
            >
              Módulos da Disciplina
            </h2>
            <p className="text-xs sm:text-sm text-[#94A3B8]">
              3 módulos estruturados · 11 subtópicos teóricos · 3 avaliações universitárias
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
            {modules.map((mod) => {
              const stats = getModuleCompletionStats(progress, mod);
              const quizScore = progress.quizScores[mod.id];

              return (
                <article
                  key={mod.id}
                  data-testid={`module-card-${mod.id}`}
                  className={`rounded-2xl bg-[#0A163D] border p-6 flex flex-col justify-between transition-colors duration-200 ${
                    stats.isComplete
                      ? 'border-[#10B981]/60'
                      : 'conti-border hover:border-[#00B4FF]/50'
                  }`}
                >
                  <div>
                    {/* Topo do Card */}
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <span className="text-xs font-mono font-semibold text-[#00B4FF] tracking-wide">
                        MÓDULO 0{mod.number}
                      </span>

                      {stats.isComplete ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#10B981] whitespace-nowrap">
                          <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                          Módulo Concluído
                        </span>
                      ) : (
                        <span className="text-xs font-medium text-[#94A3B8] tabular-nums whitespace-nowrap">
                          {stats.completed}/{stats.total} estudados
                        </span>
                      )}
                    </div>

                    <h3 className="text-lg font-display font-bold text-white leading-snug mb-2.5">
                      {mod.title}
                    </h3>

                    <p className="text-sm text-[#CBD5E1] leading-relaxed mb-5">
                      {mod.description}
                    </p>

                    {/* Lista de Subtópicos do Módulo */}
                    <div className="border-t conti-border pt-4 mb-6">
                      <p className="text-xs font-semibold text-[#94A3B8] mb-3">
                        Subtópicos incluídos
                      </p>
                      <ul className="space-y-2">
                        {mod.subtopics.map((sub) => {
                          const studied = isSubtopicStudied(progress, sub.id);
                          return (
                            <li key={sub.id}>
                              <button
                                type="button"
                                onClick={() => onOpenModule(mod.id, sub.id)}
                                className="w-full text-left group flex items-start gap-2.5 py-1.5 px-2 -mx-2 rounded-lg hover:bg-[#0F1E4E] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
                              >
                                <span
                                  aria-hidden="true"
                                  className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center shrink-0 border transition-colors ${
                                    studied
                                      ? 'bg-[#10B981] border-[#10B981] text-[#030B26]'
                                      : 'bg-[#030B26] border-[rgba(0,180,255,0.35)] text-transparent'
                                  }`}
                                >
                                  <Check className="w-3 h-3 stroke-[3]" />
                                </span>
                                <span className="text-xs sm:text-sm text-[#E2E8F0] group-hover:text-white leading-snug">
                                  <span className="font-mono text-[#00B4FF] mr-1.5 tabular-nums">
                                    {sub.code}
                                  </span>
                                  {sub.title}
                                </span>
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>

                  {/* Rodapé de Ações do Card */}
                  <div className="space-y-2.5 pt-2">
                    <button
                      type="button"
                      onClick={() => onOpenModule(mod.id, mod.subtopics[0]?.id)}
                      className="w-full conti-gradient text-white font-display font-semibold text-sm py-3 px-4 rounded-xl flex items-center justify-center gap-2 hover:opacity-95 transition-opacity whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
                    >
                      <BookOpen className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>Acessar Módulo</span>
                      <ArrowRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenQuiz(mod.id)}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#0F1E4E]/80 border conti-border text-xs font-semibold text-[#E2E8F0] hover:text-white hover:border-[#00B4FF] flex items-center justify-between gap-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
                    >
                      <span className="inline-flex items-center gap-2 whitespace-nowrap">
                        <ClipboardCheck className="w-4 h-4 text-[#00B4FF]" aria-hidden="true" />
                        Atividade Avaliativa do Módulo {mod.number}
                      </span>
                      {quizScore && (
                        <span className="text-[#10B981] font-mono tabular-nums whitespace-nowrap">
                          {quizScore.score}/{quizScore.total}
                        </span>
                      )}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </main>

      <footer className="border-t conti-border bg-[#0A163D]/40 py-5 px-5 sm:px-8">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#94A3B8]">
          <span>CONTI — Tecnologia e Informação aplicada às Ciências Contábeis</span>
          <span>Material didático universitário com referencial CPC, COSO e LGPD</span>
        </div>
      </footer>
    </div>
  );
};
