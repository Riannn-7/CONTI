import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  ClipboardCheck,
  RotateCcw,
  XCircle,
} from 'lucide-react';
import type { CourseModule } from '../types/course';
import { gradeModuleQuiz } from '../utils/progress';

interface ModuleQuizViewProps {
  module: CourseModule;
  previousScore?: { score: number; total: number };
  onSaveQuizScore: (moduleId: string, score: number, total: number) => void;
  onBackToModule: (moduleId: string, subtopicId: string) => void;
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const;

export const ModuleQuizView: React.FC<ModuleQuizViewProps> = ({
  module,
  previousScore,
  onSaveQuizScore,
  onBackToModule,
}) => {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Reinicia estado local ao trocar de módulo
  useEffect(() => {
    setAnswers({});
    setSubmitted(false);
    setValidationError(null);
  }, [module.id]);

  const answeredCount = Object.keys(answers).length;
  const totalQuestions = module.quiz.length;
  const graded = submitted ? gradeModuleQuiz(module.quiz, answers) : null;

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
    if (validationError) setValidationError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const unanswered = module.quiz.filter((q) => typeof answers[q.id] !== 'number');
    if (unanswered.length > 0) {
      setValidationError(
        `Responda todas as questões antes de finalizar (${answeredCount} de ${totalQuestions} respondidas).`
      );
      return;
    }

    const result = gradeModuleQuiz(module.quiz, answers);
    setSubmitted(true);
    setValidationError(null);
    onSaveQuizScore(module.id, result.score, result.total);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRetake = () => {
    setAnswers({});
    setSubmitted(false);
    setValidationError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section
      aria-labelledby="quiz-module-heading"
      className="max-w-4xl mx-auto px-5 sm:px-10 py-8 sm:py-10"
    >
      {/* Cabeçalho da Avaliação */}
      <header className="pb-6 mb-8 border-b conti-border">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <p className="text-xs sm:text-sm font-medium text-[#00B4FF] mb-2">
              Atividade Avaliativa · Módulo {module.number}
            </p>
            <h1
              id="quiz-module-heading"
              className="text-2xl sm:text-3xl font-display font-bold text-white leading-tight [text-wrap:balance]"
            >
              Avaliação: {module.title}
            </h1>
            <p className="mt-2 text-sm text-[#CBD5E1]">
              5 questões de múltipla escolha de nível universitário contextualizadas na prática
              contábil e fundamentadas na teoria do Módulo {module.number}.
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              onBackToModule(module.id, module.subtopics[0]?.id ?? '')
            }
            className="shrink-0 py-2.5 px-4 rounded-xl bg-[#0A163D] border conti-border text-xs font-semibold text-[#E2E8F0] hover:text-white hover:border-[#00B4FF] inline-flex items-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
          >
            <ArrowLeft className="w-4 h-4 text-[#00B4FF]" aria-hidden="true" />
            <span>Revisar teoria do módulo</span>
          </button>
        </div>
      </header>

      {/* Painel de Resultado após Correção */}
      {graded && (
        <div
          data-testid="quiz-result-banner"
          className={`mb-8 rounded-2xl border p-6 sm:p-7 ${
            graded.percent >= 60
              ? 'bg-[#10B981]/10 border-[#10B981]/50'
              : 'bg-[#0A163D] border-[#00B4FF]/40'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
            <div>
              <div className="flex items-center gap-2 mb-2">
                {graded.percent >= 60 ? (
                  <CheckCircle2 className="w-5 h-5 text-[#10B981]" aria-hidden="true" />
                ) : (
                  <ClipboardCheck className="w-5 h-5 text-[#00B4FF]" aria-hidden="true" />
                )}
                <span
                  className={`text-sm font-semibold ${
                    graded.percent >= 60 ? 'text-[#10B981]' : 'text-[#00B4FF]'
                  }`}
                >
                  {graded.percent >= 80
                    ? 'Desempenho Excelente'
                    : graded.percent >= 60
                      ? 'Aproveitamento Satisfatório'
                      : 'Reforce a leitura do módulo e tente novamente'}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-display font-bold text-white tabular-nums">
                Nota: {graded.score} de {graded.total} acertos ({graded.percent}%)
              </h2>
              <p className="mt-1.5 text-sm text-[#CBD5E1]">
                Confira abaixo a correção comentada de cada questão com a fundamentação teórica
                correspondente.
              </p>
            </div>

            <button
              type="button"
              onClick={handleRetake}
              className="conti-gradient text-white font-display font-semibold text-sm py-3 px-5 rounded-xl inline-flex items-center justify-center gap-2 hover:opacity-95 transition-opacity whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Refazer Avaliação</span>
            </button>
          </div>
        </div>
      )}

      {/* Aviso de última nota registrada antes de enviar */}
      {!submitted && previousScore && (
        <div className="mb-6 rounded-xl bg-[#0A163D] border conti-border px-5 py-3.5 flex items-center justify-between gap-3 text-xs sm:text-sm">
          <span className="text-[#CBD5E1]">
            Última nota registrada neste módulo:
          </span>
          <span className="font-mono font-semibold text-[#10B981] tabular-nums">
            {previousScore.score}/{previousScore.total} (
            {Math.round((previousScore.score / previousScore.total) * 100)}%)
          </span>
        </div>
      )}

      {/* Formulário das 5 Questões */}
      <form onSubmit={handleSubmit} className="space-y-7" noValidate>
        {module.quiz.map((question, qIndex) => {
          const selected = answers[question.id];
          const qResult = graded?.results.find((r) => r.questionId === question.id);

          return (
            <fieldset
              key={question.id}
              data-testid={`quiz-question-${qIndex + 1}`}
              className="rounded-2xl bg-[#0A163D] border conti-border p-5 sm:p-7"
            >
              <legend className="sr-only">
                Questão {qIndex + 1} de {totalQuestions}
              </legend>

              <div className="flex items-center justify-between gap-3 mb-3">
                <span className="text-xs font-mono font-semibold text-[#00B4FF] tabular-nums">
                  QUESTÃO {qIndex + 1} DE {totalQuestions}
                </span>

                {qResult && (
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                      qResult.isCorrect ? 'text-[#10B981]' : 'text-rose-400'
                    }`}
                  >
                    {qResult.isCorrect ? (
                      <>
                        <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                        Resposta Correta
                      </>
                    ) : (
                      <>
                        <XCircle className="w-4 h-4" aria-hidden="true" />
                        Resposta Incorreta
                      </>
                    )}
                  </span>
                )}
              </div>

              <p className="text-base font-medium text-white leading-relaxed mb-5">
                {question.prompt}
              </p>

              <div className="space-y-3" role="radiogroup" aria-label={`Alternativas da questão ${qIndex + 1}`}>
                {question.options.map((option, optIdx) => {
                  const isSelected = selected === optIdx;
                  const isCorrectOpt = question.correctIndex === optIdx;

                  let optionStyle =
                    'bg-[#030B26]/70 border-[rgba(0,180,255,0.2)] text-[#E2E8F0] hover:border-[#00B4FF]/60';

                  if (!submitted && isSelected) {
                    optionStyle =
                      'bg-[#0F1E4E] border-[#00B4FF] text-white ring-1 ring-[#00B4FF]/50';
                  } else if (submitted && isCorrectOpt) {
                    optionStyle =
                      'bg-[#10B981]/15 border-[#10B981] text-white';
                  } else if (submitted && isSelected && !isCorrectOpt) {
                    optionStyle =
                      'bg-rose-500/15 border-rose-400/70 text-[#F1F5F9]';
                  }

                  return (
                    <label
                      key={optIdx}
                      className={`flex items-start gap-3.5 p-4 rounded-xl border transition-colors ${
                        submitted ? 'cursor-default' : 'cursor-pointer'
                      } ${optionStyle}`}
                    >
                      <input
                        type="radio"
                        name={question.id}
                        value={optIdx}
                        checked={isSelected}
                        disabled={submitted}
                        onChange={() => handleSelectOption(question.id, optIdx)}
                        className="sr-only"
                      />
                      <span
                        aria-hidden="true"
                        className={`w-6 h-6 rounded-md font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 border ${
                          submitted && isCorrectOpt
                            ? 'bg-[#10B981] border-[#10B981] text-[#030B26]'
                            : submitted && isSelected && !isCorrectOpt
                              ? 'bg-rose-500 border-rose-400 text-white'
                              : isSelected
                                ? 'bg-[#00B4FF] border-[#00B4FF] text-[#030B26]'
                                : 'bg-[#0A163D] border-[rgba(0,180,255,0.3)] text-[#00B4FF]'
                        }`}
                      >
                        {OPTION_LETTERS[optIdx]}
                      </span>
                      <span className="text-sm leading-relaxed flex-1">{option}</span>
                    </label>
                  );
                })}
              </div>

              {/* Feedback Explicativo após Correção */}
              {submitted && (
                <div className="mt-5 pt-4 border-t conti-border text-sm leading-relaxed text-[#CBD5E1]">
                  <p className="font-semibold text-white mb-1">
                    Justificativa (Alternativa {OPTION_LETTERS[question.correctIndex]}):
                  </p>
                  <p>{question.explanation}</p>
                </div>
              )}
            </fieldset>
          );
        })}

        {validationError && (
          <div
            role="alert"
            className="rounded-xl bg-amber-500/10 border border-amber-400/40 px-5 py-3.5 flex items-center gap-3 text-sm text-amber-200"
          >
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" aria-hidden="true" />
            <span>{validationError}</span>
          </div>
        )}

        {!submitted && (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
            <p className="text-sm text-[#94A3B8] tabular-nums">
              Questões respondidas: <strong className="text-white">{answeredCount}</strong> de{' '}
              <strong className="text-white">{totalQuestions}</strong>
            </p>
            <button
              type="submit"
              className="conti-gradient text-white font-display font-semibold text-sm py-3.5 px-7 rounded-xl inline-flex items-center justify-center gap-2 hover:opacity-95 transition-opacity whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <ClipboardCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Finalizar e Corrigir Avaliação</span>
            </button>
          </div>
        )}
      </form>
    </section>
  );
};
