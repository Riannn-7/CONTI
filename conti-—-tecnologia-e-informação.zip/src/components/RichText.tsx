import React from 'react';
import type { ContentTable } from '../types/course';

/**
 * Renders inline bold (**...**), italic (*...*), and monospace (`...`) spans safely as React nodes.
 */
export function renderFormattedText(text: string): React.ReactNode[] {
  const tokens = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g);
  return tokens.map((token, idx) => {
    if (token.startsWith('**') && token.endsWith('**')) {
      return (
        <strong key={idx} className="font-semibold text-white">
          {token.slice(2, -2)}
        </strong>
      );
    }
    if (token.startsWith('*') && token.endsWith('*')) {
      return (
        <em key={idx} className="italic text-[#F1F5F9]">
          {token.slice(1, -1)}
        </em>
      );
    }
    if (token.startsWith('`') && token.endsWith('`')) {
      return (
        <code
          key={idx}
          className="font-mono text-[0.92em] px-1.5 py-0.5 rounded bg-[#0F1E4E] text-[#38BDF8] border border-[rgba(0,180,255,0.25)] tabular-nums"
        >
          {token.slice(1, -1)}
        </code>
      );
    }
    return <React.Fragment key={idx}>{token}</React.Fragment>;
  });
}

interface AcademicTableProps {
  table: ContentTable;
}

export const AcademicTable: React.FC<AcademicTableProps> = ({ table }) => {
  return (
    <div className="my-8 rounded-xl bg-[#0A163D] border conti-border overflow-hidden">
      {table.title && (
        <div className="px-5 py-3.5 bg-[#0F1E4E] border-b conti-border">
          <h4 className="text-sm font-display font-semibold text-white tracking-wide">
            {table.title}
          </h4>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[620px]">
          <thead>
            <tr className="border-b conti-border bg-[#0F1E4E]/60">
              {table.headers.map((header, idx) => (
                <th
                  key={idx}
                  scope="col"
                  className="px-5 py-3.5 text-xs font-display font-bold text-[#00B4FF] tracking-wide"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[rgba(0,180,255,0.14)]">
            {table.rows.map((row, rowIdx) => (
              <tr
                key={rowIdx}
                className="hover:bg-[#0F1E4E]/45 transition-colors duration-150"
              >
                {row.map((cell, cellIdx) => (
                  <td
                    key={cellIdx}
                    className="px-5 py-4 text-sm leading-relaxed text-[#E2E8F0] align-top"
                  >
                    {renderFormattedText(cell)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
