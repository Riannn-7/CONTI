import React, { useState } from 'react';
import {
  Check,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  Home,
  PanelLeftClose,
  RotateCcw,
  X,
} from 'lucide-react';
import type { ActiveRoute, CourseModule, PersistedProgress } from '../types/course';
import {
  getOverallProgress,
  isModuleCompleted,
  isSubtopicStudied,
} from '../utils/progress';
import { ContiLogo } from './ContiLogo';

interface StudySidebarProps {
  modules: CourseModule[];
  progress: PersistedProgress;
  activeRoute: ActiveRoute;
  isDesktopOpen: boolean;
  isMobileOpen: boolean;
  expandedModuleIds: string[];
  onToggleDesktop: () => void;
  onCloseMobile: () => void;
  onToggleAccordion: (moduleId: string) => void;
  onNavigateHome: () => void;
  onSelectSubtopic: (moduleId: string, subtopicId: string) => void;
  onSelectQuiz: (moduleId: string) => void;
  onToggleStudied: (subtopicId: string) => void;
  onClearProgress: () => void;
}

export const StudySidebar: React.FC<StudySidebarProps> = ({
  modules,
  progress,
  activeRoute,
  isDesktopOpen,
  isMobileOpen,
  expandedModuleIds,
  onToggleDesktop,
  onCloseMobile,
  onToggleAccordion,
  onNavigateHome,
  onSelectSubtopic,
  onSelectQuiz,
  onToggleStudied,
  onClearProgress,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);
  const overall = getOverallProgress(progress, modules);

  const sidebarBody = (
    <div className="h-full flex flex-col bg-[#0A163D] border-r conti-border">
      {/* Cabeçalho da Sidebar */}
      <div className="px-4 py-4 border-b conti-border flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={onNavigateHome}
          aria-label="Voltar ao Menu Inicial CONTI"
          className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF] rounded-lg p-1 -m-1"
        >
          <ContiLogo size="sm" />
        </button>

        {/* Botão recolher no desktop */}
        <button
          type="button"
          onClick={onToggleDesktop}
          aria-label="Recolher barra lateral"
          title="Recolher barra lateral"
          className="hidden lg:flex w-9 h-9 rounded-lg bg-[#0F1E4E] border conti-border text-[#CBD5E1] hover:text-white hover:border-[#00B4FF] items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
        >
          <PanelLeftClose className="w-4 h-4" aria-hidden="true" />
        </button>

        {/* Botão fechar no mobile */}
        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Fechar menu de navegação"
          className="lg:hidden flex w-10 h-10 rounded-lg bg-[#0F1E4E] border conti-border text-[#CBD5E1] hover:text-white items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
        >
          <X className="w-5 h-5" aria-hidden="true" />
        </button>
      </div>

      {/* Botão Menu Inicial + Mini Progresso */}
      <div className="px-4 py-3.5 border-b conti-border space-y-3">
        <button
          type="button"
          onClick={onNavigateHome}
          className="w-full py-2.5 px-3 rounded-lg bg-[#0F1E4E] border conti-border text-xs font-semibold text-white hover:border-[#00B4FF] flex items-center gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
        >
          <Home className="w-4 h-4 text-[#00B4FF]" aria-hidden="true" />
          <span>Voltar ao Menu Inicial</span>
        </button>

        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-[#94A3B8]">Progresso total</span>
            <span className="font-mono font-semibold text-white tabular-nums">
              {overall.completed}/{overall.total} ({overall.percent}%)
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#030B26] overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                overall.completed > 0 ? 'bg-[#10B981]' : 'bg-[#00B4FF]'
              }`}
              style={{ width: `${overall.percent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Navegação Acordeão dos 3 Módulos */}
      <nav aria-label="Estrutura do curso" className="flex-1 overflow-y-auto px-3 py-4 space-y-2.5">
        {modules.map((mod) => {
          const isExpanded = expandedModuleIds.includes(mod.id);
          const moduleComplete = isModuleCompleted(progress, mod);
          const isModuleActive =
            (activeRoute.type === 'subtopic' || activeRoute.type === 'quiz') &&
            activeRoute.moduleId === mod.id;

          return (
            <div
              key={mod.id}
              className={`rounded-xl border transition-colors ${
                isModuleActive
                  ? 'bg-[#0F1E4E]/75 border-[#00B4FF]/35'
                  : 'bg-[#030B26]/45 conti-border'
              }`}
            >
              {/* Cabeçalho do Módulo Principal */}
              <div className="flex items-center gap-2 p-2.5">
                <span
                  data-testid={`sidebar-module-check-${mod.id}`}
                  aria-label={
                    moduleComplete
                      ? `Módulo ${mod.number} concluído`
                      : `Módulo ${mod.number} em andamento`
                  }
                  title={
                    moduleComplete
                      ? 'Módulo inteiro concluído'
                      : 'Conclua todos os subtópicos para completar este módulo'
                  }
                  className={`w-5 h-5 rounded flex items-center justify-center shrink-0 border transition-colors ${
                    moduleComplete
                      ? 'bg-[#10B981] border-[#10B981] text-[#030B26]'
                      : 'bg-[#030B26] border-[rgba(0,180,255,0.35)] text-transparent'
                  }`}
                >
                  <Check className="w-3.5 h-3.5 stroke-[3]" aria-hidden="true" />
                </span>

                <button
                  type="button"
                  aria-expanded={isExpanded}
                  onClick={() => onToggleAccordion(mod.id)}
                  className="flex-1 text-left flex items-center justify-between gap-2 min-w-0 py-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF] rounded"
                >
                  <span className="text-xs font-display font-bold text-white leading-snug">
                    Módulo {mod.number}: {mod.shortTitle}
                  </span>
                  {isExpanded ? (
                    <ChevronDown
                      className="w-4 h-4 text-[#00B4FF] shrink-0"
                      aria-hidden="true"
                    />
                  ) : (
                    <ChevronRight
                      className="w-4 h-4 text-[#94A3B8] shrink-0"
                      aria-hidden="true"
                    />
                  )}
                </button>
              </div>

              {/* Lista de Subtópicos + Atividade Avaliativa */}
              {isExpanded && (
                <div className="px-2 pb-2.5 pt-1 space-y-1 border-t border-[rgba(0,180,255,0.12)]">
                  {mod.subtopics.map((sub) => {
                    const studied = isSubtopicStudied(progress, sub.id);
                    const isSubActive =
                      activeRoute.type === 'subtopic' && activeRoute.subtopicId === sub.id;

                    return (
                      <div
                        key={sub.id}
                        className={`flex items-start gap-2 rounded-lg px-2 py-1.5 transition-colors ${
                          isSubActive
                            ? 'bg-[#00B4FF]/15 text-white'
                            : 'text-[#CBD5E1] hover:bg-[#0F1E4E]/70 hover:text-white'
                        }`}
                      >
                        <button
                          type="button"
                          data-testid={`sidebar-subtopic-check-${sub.id}`}
                          onClick={() => onToggleStudied(sub.id)}
                          aria-pressed={studied}
                          aria-label={
                            studied
                              ? `Desmarcar subtópico ${sub.code} como estudado`
                              : `Marcar subtópico ${sub.code} como estudado`
                          }
                          className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center shrink-0 border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#10B981] ${
                            studied
                              ? 'bg-[#10B981] border-[#10B981] text-[#030B26]'
                              : 'bg-[#030B26] border-[rgba(0,180,255,0.35)] text-transparent hover:border-[#00B4FF]'
                          }`}
                        >
                          <Check className="w-3 h-3 stroke-[3]" aria-hidden="true" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onSelectSubtopic(mod.id, sub.id);
                            onCloseMobile();
                          }}
                          className="flex-1 text-left text-xs leading-snug focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF] rounded"
                        >
                          <span
                            className={`font-mono mr-1 tabular-nums ${
                              isSubActive ? 'text-[#00B4FF] font-semibold' : 'text-[#94A3B8]'
                            }`}
                          >
                            {sub.code}
                          </span>
                          <span className={isSubActive ? 'font-semibold text-white' : ''}>
                            {sub.title}
                          </span>
                        </button>
                      </div>
                    );
                  })}

                  {/* Item final do módulo: Atividade Avaliativa */}
                  <button
                    type="button"
                    onClick={() => {
                      onSelectQuiz(mod.id);
                      onCloseMobile();
                    }}
                    className={`w-full mt-1.5 flex items-center gap-2 rounded-lg px-2 py-2 text-left text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF] ${
                      activeRoute.type === 'quiz' && activeRoute.moduleId === mod.id
                        ? 'conti-gradient text-white'
                        : 'bg-[#0F1E4E]/60 text-[#E2E8F0] hover:bg-[#0F1E4E] hover:text-white'
                    }`}
                  >
                    <ClipboardCheck className="w-4 h-4 shrink-0 text-[#00B4FF]" aria-hidden="true" />
                    <span className="leading-snug">Atividade Avaliativa do Módulo</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Rodapé da Sidebar: Limpar Progresso */}
      <div className="px-4 py-3.5 border-t conti-border bg-[#030B26]/50">
        {!confirmReset ? (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="w-full py-2 px-3 rounded-lg text-xs text-[#94A3B8] hover:text-white hover:bg-[#0F1E4E] flex items-center justify-center gap-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Limpar progresso</span>
          </button>
        ) : (
          <div className="space-y-2">
            <p className="text-xs text-[#E2E8F0] text-center">
              Deseja zerar todas as marcações?
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  onClearProgress();
                  setConfirmReset(false);
                }}
                className="py-1.5 px-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white transition-colors"
              >
                Confirmar
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="py-1.5 px-2.5 rounded-lg bg-[#0F1E4E] border conti-border text-xs font-medium text-[#E2E8F0] hover:text-white transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Collapsible Sidebar */}
      <aside
        aria-label="Barra lateral de estudos"
        className={`hidden lg:block shrink-0 transition-all duration-200 overflow-hidden ${
          isDesktopOpen ? 'w-80' : 'w-0'
        }`}
      >
        <div className="w-80 h-screen sticky top-0">{sidebarBody}</div>
      </aside>

      {/* Mobile Drawer Sidebar */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div
            className="fixed inset-0 bg-[#030B26]/80 backdrop-blur-sm"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside
            aria-label="Menu lateral de estudos"
            className="relative z-10 w-[85vw] max-w-xs h-full shadow-2xl"
          >
            {sidebarBody}
          </aside>
        </div>
      )}
    </>
  );
};
