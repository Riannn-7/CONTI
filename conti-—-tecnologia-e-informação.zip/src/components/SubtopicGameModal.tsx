import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import type { Subtopic } from '../types/course';
import { renderSubtopicGame } from '../games/renderSubtopicGame';

interface SubtopicGameModalProps {
  subtopic: Subtopic | null;
  onClose: () => void;
}

export const SubtopicGameModal: React.FC<SubtopicGameModalProps> = ({
  subtopic,
  onClose,
}) => {
  useEffect(() => {
    if (!subtopic) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [subtopic, onClose]);

  if (!subtopic) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#030B26]/85 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="subtopic-game-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-2xl bg-[#0A163D] border conti-border shadow-2xl shadow-black/60 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 px-6 py-5 bg-[#0F1E4E] border-b conti-border">
          <div className="min-w-0">
            <p className="text-xs font-medium text-[#00B4FF] mb-1">
              Atividade Prática Interativa
            </p>
            <h2
              id="subtopic-game-modal-title"
              className="text-lg sm:text-xl font-display font-bold text-white leading-snug"
            >
              Desafio Interativo: {subtopic.code} {subtopic.title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar desafio interativo"
            className="shrink-0 w-10 h-10 rounded-lg bg-[#0A163D] border conti-border text-[#CBD5E1] hover:text-white hover:border-[#00B4FF] flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="p-6 sm:p-7">
          {renderSubtopicGame(subtopic.id, `${subtopic.code} ${subtopic.title}`)}

          <div className="mt-6 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-lg bg-[#0F1E4E] border conti-border text-sm font-semibold text-white hover:border-[#00B4FF] transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              Voltar para a leitura
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
