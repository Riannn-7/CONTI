import React, { useState } from 'react';
import { ImageOff, Maximize2 } from 'lucide-react';
import type { InfographicItem } from '../types/course';

interface InfographicCardProps {
  infographic: InfographicItem;
  onExpand: (item: InfographicItem) => void;
}

export const InfographicCard: React.FC<InfographicCardProps> = ({
  infographic,
  onExpand,
}) => {
  const [hasError, setHasError] = useState(false);

  return (
    <figure
      data-testid={`infographic-card-${infographic.id}`}
      className="my-8 rounded-2xl p-[1px] bg-gradient-to-br from-[#00B4FF]/40 via-[#4F46E5]/30 to-[#00B4FF]/20 shadow-xl shadow-black/30"
    >
      <div className="rounded-[15px] bg-[#0A163D] overflow-hidden">
        <div className="relative bg-[#030B26]">
          {!hasError ? (
            <button
              type="button"
              onClick={() => onExpand(infographic)}
              aria-label={`Ampliar infográfico: ${infographic.title}`}
              className="group relative block w-full text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF] focus-visible:ring-inset cursor-zoom-in"
            >
              <img
                src={infographic.src}
                alt={infographic.alt}
                referrerPolicy="no-referrer"
                loading="lazy"
                onError={() => setHasError(true)}
                className="w-full h-auto block object-contain transition-transform duration-200 group-hover:scale-[1.008]"
              />
            </button>
          ) : (
            <div className="aspect-video w-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#0A163D] to-[#030B26] border-b conti-border">
              <div className="w-12 h-12 rounded-xl bg-[#0F1E4E] border conti-border flex items-center justify-center text-[#00B4FF] mb-3">
                <ImageOff className="w-6 h-6" aria-hidden="true" />
              </div>
              <p className="text-sm font-display font-semibold text-white mb-1">
                {infographic.title}
              </p>
              <p className="text-xs text-[#94A3B8] max-w-md">
                Infográfico ilustrativo indisponível no momento. Consulte o caminho do arquivo ou
                recarregue a página.
              </p>
            </div>
          )}
        </div>

        <figcaption className="px-5 py-4 bg-[#0A163D] border-t border-[rgba(0,180,255,0.16)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs sm:text-sm font-display font-semibold text-white">
              {infographic.title}
            </p>
            <p className="text-xs text-[#CBD5E1] mt-0.5 leading-relaxed">
              {infographic.caption}
            </p>
          </div>
          {!hasError && (
            <button
              type="button"
              onClick={() => onExpand(infographic)}
              className="self-start sm:self-center shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0F1E4E] border conti-border text-xs font-semibold text-[#00B4FF] hover:text-white hover:border-[#00B4FF] transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00B4FF]"
            >
              <Maximize2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Ampliar</span>
            </button>
          )}
        </figcaption>
      </div>
    </figure>
  );
};
