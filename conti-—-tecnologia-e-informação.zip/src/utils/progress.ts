import type { CourseModule, PersistedProgress, QuizQuestion } from '../types/course';

export const STORAGE_KEY = 'conti_study_progress_v1';

export const EMPTY_PROGRESS: PersistedProgress = {
  studiedSubtopics: [],
  quizScores: {},
};

export function getTotalSubtopicCount(modules: CourseModule[]): number {
  return modules.reduce((acc, mod) => acc + mod.subtopics.length, 0);
}

export function isSubtopicStudied(progress: PersistedProgress, subtopicId: string): boolean {
  return progress.studiedSubtopics.includes(subtopicId);
}

export function isModuleCompleted(progress: PersistedProgress, module: CourseModule): boolean {
  if (module.subtopics.length === 0) return false;
  return module.subtopics.every((sub) => progress.studiedSubtopics.includes(sub.id));
}

export function getModuleCompletionStats(
  progress: PersistedProgress,
  module: CourseModule
): { completed: number; total: number; percent: number; isComplete: boolean } {
  const total = module.subtopics.length;
  const completed = module.subtopics.filter((sub) =>
    progress.studiedSubtopics.includes(sub.id)
  ).length;
  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
  return {
    completed,
    total,
    percent,
    isComplete: total > 0 && completed === total,
  };
}

export function getOverallProgress(
  progress: PersistedProgress,
  modules: CourseModule[]
): { completed: number; total: number; percent: number; completedModules: number } {
  const validIds = new Set(modules.flatMap((m) => m.subtopics.map((s) => s.id)));
  const completed = progress.studiedSubtopics.filter((id) => validIds.has(id)).length;
  const total = validIds.size;
  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
  const completedModules = modules.filter((m) => isModuleCompleted(progress, m)).length;
  return { completed, total, percent, completedModules };
}

export function toggleSubtopicStudied(
  progress: PersistedProgress,
  subtopicId: string
): PersistedProgress {
  const exists = progress.studiedSubtopics.includes(subtopicId);
  const studiedSubtopics = exists
    ? progress.studiedSubtopics.filter((id) => id !== subtopicId)
    : [...progress.studiedSubtopics, subtopicId];

  return {
    ...progress,
    studiedSubtopics,
  };
}

export function gradeModuleQuiz(
  questions: QuizQuestion[],
  answers: Record<string, number>
): {
  score: number;
  total: number;
  percent: number;
  results: Array<{
    questionId: string;
    selectedIndex: number | null;
    correctIndex: number;
    isCorrect: boolean;
  }>;
} {
  const results = questions.map((q) => {
    const selected = typeof answers[q.id] === 'number' ? answers[q.id] : null;
    const isCorrect = selected === q.correctIndex;
    return {
      questionId: q.id,
      selectedIndex: selected,
      correctIndex: q.correctIndex,
      isCorrect,
    };
  });

  const score = results.filter((r) => r.isCorrect).length;
  const total = questions.length;
  const percent = total > 0 ? Math.round((score / total) * 100) : 0;

  return { score, total, percent, results };
}

export function serializeProgress(progress: PersistedProgress): string {
  return JSON.stringify(progress);
}

export function parseProgress(raw: string | null): PersistedProgress {
  if (!raw) return EMPTY_PROGRESS;
  try {
    const parsed = JSON.parse(raw) as Partial<PersistedProgress>;
    const studiedSubtopics = Array.isArray(parsed.studiedSubtopics)
      ? parsed.studiedSubtopics.filter((id): id is string => typeof id === 'string')
      : [];
    const quizScores: Record<string, { score: number; total: number }> = {};
    if (parsed.quizScores && typeof parsed.quizScores === 'object') {
      for (const [k, v] of Object.entries(parsed.quizScores)) {
        if (v && typeof v.score === 'number' && typeof v.total === 'number') {
          quizScores[k] = { score: v.score, total: v.total };
        }
      }
    }
    return { studiedSubtopics, quizScores };
  } catch {
    return EMPTY_PROGRESS;
  }
}

export function loadProgressFromStorage(): PersistedProgress {
  if (typeof window === 'undefined') return EMPTY_PROGRESS;
  try {
    return parseProgress(window.localStorage.getItem(STORAGE_KEY));
  } catch {
    return EMPTY_PROGRESS;
  }
}

export function saveProgressToStorage(progress: PersistedProgress): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, serializeProgress(progress));
  } catch {
    // Ignore storage quota / private mode failures gracefully
  }
}

export function clearProgressFromStorage(): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Ignore storage failures gracefully
  }
}
