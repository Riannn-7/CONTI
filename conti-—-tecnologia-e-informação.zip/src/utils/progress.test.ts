import test from 'node:test';
import assert from 'node:assert/strict';
import type { CourseModule, QuizQuestion } from '../types/course';
import {
  EMPTY_PROGRESS,
  getModuleCompletionStats,
  getOverallProgress,
  gradeModuleQuiz,
  isModuleCompleted,
  isSubtopicStudied,
  parseProgress,
  serializeProgress,
  toggleSubtopicStudied,
} from './progress';

const SAMPLE_QUIZ: QuizQuestion[] = [
  {
    id: 'q1',
    prompt: 'Pergunta 1',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 1,
    explanation: 'B está correta.',
  },
  {
    id: 'q2',
    prompt: 'Pergunta 2',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 3,
    explanation: 'D está correta.',
  },
];

const SAMPLE_MODULES: CourseModule[] = [
  {
    id: 'mod-1',
    number: 1,
    title: 'Módulo 1',
    shortTitle: 'Módulo 1',
    description: 'Desc 1',
    subtopics: [
      { id: '1.1', slotKey: '1_1', code: '1.1', title: 'Sub 1.1', paragraphs: ['Texto'] },
      { id: '1.2', slotKey: '1_2', code: '1.2', title: 'Sub 1.2', paragraphs: ['Texto'] },
    ],
    references: [],
    quiz: SAMPLE_QUIZ,
  },
  {
    id: 'mod-2',
    number: 2,
    title: 'Módulo 2',
    shortTitle: 'Módulo 2',
    description: 'Desc 2',
    subtopics: [
      { id: '2.1', slotKey: '2_1', code: '2.1', title: 'Sub 2.1', paragraphs: ['Texto'] },
    ],
    references: [],
    quiz: SAMPLE_QUIZ,
  },
];

test('toggleSubtopicStudied marks and unmarks subtopics cleanly', () => {
  let state = EMPTY_PROGRESS;
  assert.equal(isSubtopicStudied(state, '1.1'), false);

  state = toggleSubtopicStudied(state, '1.1');
  assert.equal(isSubtopicStudied(state, '1.1'), true);
  assert.deepEqual(state.studiedSubtopics, ['1.1']);

  state = toggleSubtopicStudied(state, '1.1');
  assert.equal(isSubtopicStudied(state, '1.1'), false);
  assert.deepEqual(state.studiedSubtopics, []);
});

test('isModuleCompleted triggers automatically only when all subtopics are studied', () => {
  let state = EMPTY_PROGRESS;
  assert.equal(isModuleCompleted(state, SAMPLE_MODULES[0]), false);

  state = toggleSubtopicStudied(state, '1.1');
  assert.equal(isModuleCompleted(state, SAMPLE_MODULES[0]), false);
  assert.deepEqual(getModuleCompletionStats(state, SAMPLE_MODULES[0]), {
    completed: 1,
    total: 2,
    percent: 50,
    isComplete: false,
  });

  state = toggleSubtopicStudied(state, '1.2');
  assert.equal(isModuleCompleted(state, SAMPLE_MODULES[0]), true);
  assert.deepEqual(getModuleCompletionStats(state, SAMPLE_MODULES[0]), {
    completed: 2,
    total: 2,
    percent: 100,
    isComplete: true,
  });

  // Unmarking one subtopic immediately reverts module completion
  state = toggleSubtopicStudied(state, '1.1');
  assert.equal(isModuleCompleted(state, SAMPLE_MODULES[0]), false);
});

test('getOverallProgress computes counts, percentages, and ignores unknown IDs', () => {
  const state = {
    studiedSubtopics: ['1.1', '2.1', '99.9'],
    quizScores: {},
  };
  assert.deepEqual(getOverallProgress(state, SAMPLE_MODULES), {
    completed: 2,
    total: 3,
    percent: 67,
    completedModules: 1,
  });
});

test('gradeModuleQuiz computes exact score, percentage, and per-question results', () => {
  const graded = gradeModuleQuiz(SAMPLE_QUIZ, { q1: 1, q2: 0 });
  assert.equal(graded.score, 1);
  assert.equal(graded.total, 2);
  assert.equal(graded.percent, 50);
  assert.equal(graded.results[0].isCorrect, true);
  assert.equal(graded.results[1].isCorrect, false);
  assert.equal(graded.results[1].correctIndex, 3);
});

test('parseProgress safely restores valid JSON and rejects malformed payloads', () => {
  const raw = serializeProgress({
    studiedSubtopics: ['1.1', '1.2'],
    quizScores: { 'mod-1': { score: 4, total: 5 } },
  });
  const restored = parseProgress(raw);
  assert.deepEqual(restored.studiedSubtopics, ['1.1', '1.2']);
  assert.deepEqual(restored.quizScores['mod-1'], { score: 4, total: 5 });

  assert.deepEqual(parseProgress('{invalid json'), EMPTY_PROGRESS);
  assert.deepEqual(parseProgress(null), EMPTY_PROGRESS);
});
